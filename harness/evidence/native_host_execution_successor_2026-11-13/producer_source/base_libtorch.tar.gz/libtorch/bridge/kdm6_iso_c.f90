!
! kdm6_iso_c — Fortran ISO_C_BINDING wrapper for libkdm6_c.
! KIM-meso 측 microphysics dispatcher가 `use kdm6_iso_c` 후
! `call kdm6_step(...)`로 호출. 인터페이스는 C ABI(kdm6_c_api.h) 1:1 매핑.
!
! 컴파일: gfortran -c kdm6_iso_c.f90  (libkdm6_c.{so,dylib} 와 함께 링크)
!
module kdm6_iso_c
  use, intrinsic :: iso_c_binding
  implicit none
  private

  ! ── 에러 코드 (kdm6_c_api.h enum과 동기) ────────────────────────────────────
  integer(c_int), parameter, public :: KDM6_OK                  = 0
  integer(c_int), parameter, public :: KDM6_ERR_INVALID_DIM     = -1
  integer(c_int), parameter, public :: KDM6_ERR_NULL_POINTER    = -2
  integer(c_int), parameter, public :: KDM6_ERR_NOT_IMPLEMENTED = -3
  integer(c_int), parameter, public :: KDM6_ERR_HANDLE_CLOSED   = -4
  integer(c_int), parameter, public :: KDM6_ERR_VALUE_ONLY      = -5
  integer(c_int), parameter, public :: KDM6_ERR_INVALID_ARG     = -6
  integer(c_int), parameter, public :: KDM6_ERR_THREAD_CONFIG   = -7
  integer(c_int), parameter, public :: KDM6_ERR_INTERNAL        = -100

  ! ── param_grad_flags 비트마스크 ────────────────────────────────────────────
  integer(c_int), parameter, public :: KDM6_GRAD_PEAUT  = 1
  integer(c_int), parameter, public :: KDM6_GRAD_NCRK1  = 2
  integer(c_int), parameter, public :: KDM6_GRAD_NCRK2  = 4
  integer(c_int), parameter, public :: KDM6_GRAD_ECCBRK = 8
  integer(c_int), parameter, public :: KDM6_GRAD_ALL    = 15

  ! ── stable ABI v2 (docs/PR2_ABI_V2_DESIGN.md) ───────────────────────────────
  integer(c_int), parameter, public :: KDM6_ABI_VERSION = 2

  ! ── physics_variant selector values (kdm6_c_api.h kdm6_physics_variant) ────
  ! 0 = legacy, 1 = historical conservative interface,
  ! 2 = conservative interface with normalized first ice handoff; others are
  ! rejected by the C side with KDM6_ERR_INVALID_ARG.
  integer(c_int32_t), parameter, public :: KDM6_PHYSICS_LEGACY = 0_c_int32_t
  integer(c_int32_t), parameter, public :: KDM6_PHYSICS_CONSERVATIVE_INTERFACE = 1_c_int32_t
  integer(c_int32_t), parameter, public :: KDM6_PHYSICS_CONSERVATIVE_NORMALIZED = 2_c_int32_t

  ! Interoperable mirror of the C `kdm6_step_v2_args` — field ORDER and types
  ! MUST match the C struct exactly; a size/layout drift is caught at run time
  ! by asserting c_sizeof(this) == kdm6_step_v2_args_size_c() (test_fortran_smoke).
  type, bind(C), public :: kdm6_step_v2_args_t
     integer(c_int32_t) :: struct_size
     integer(c_int32_t) :: abi_version
     integer(c_int32_t) :: im, kme, jme
     real(c_double)     :: dt
     integer(c_int32_t) :: value_only
     integer(c_int32_t) :: param_grad_flags
     type(c_ptr) :: th, qv, qc, qr, qi, qs, qg, nccn, nc, ni, nr, bg
     type(c_ptr) :: rho, pii, p, delz
     type(c_ptr) :: th_out, qv_out, qc_out, qr_out, qi_out, qs_out, qg_out
     type(c_ptr) :: nccn_out, nc_out, ni_out, nr_out, bg_out
     type(c_ptr) :: handle
     type(c_ptr) :: xland
     real(c_double) :: ncmin_land, ncmin_sea ! dry_number=1: numeric #/m^3 thresholds
     type(c_ptr) :: rain_increment, snow_increment, graupel_increment
     type(c_ptr) :: rhog_out
     ! conservative-interface-v1 selector: 0 = legacy (default), 1 =
     ! conservative interface variant; other values are rejected by the C side.
     integer(c_int32_t) :: physics_variant
     ! Independent S2 selector (64-bit to grow past the old C tail padding).
     ! 0 = legacy raw numbers, 1 = host dry-specific QN (value-only here).
     ! Selector 1 keeps existing number thresholds/caps in internal #/m^3.
     integer(c_int64_t) :: dry_number
  end type kdm6_step_v2_args_t

  public :: kdm6_step, kdm6_step_ad, kdm6_step_ad_variant, kdm6_step_ad_number
  public :: kdm6_step_ad_state_forcing
  public :: kdm6_handle_vjp, kdm6_handle_jvp, kdm6_handle_close
  public :: kdm6_handle_state_forcing_vjp, kdm6_handle_state_forcing_jvp
  public :: kdm6_get_abi_version_c, kdm6_step_v2_args_size_c, kdm6_step_v2_c

  ! ── C ABI interfaces ───────────────────────────────────────────────────────
  interface
    ! v2 (additive): version + struct-size introspection and the v2 forward.
    function kdm6_get_abi_version_c() &
        bind(C, name="kdm6_get_abi_version_c") result(v)
      import :: c_int
      integer(c_int) :: v
    end function kdm6_get_abi_version_c

    function kdm6_step_v2_args_size_c() &
        bind(C, name="kdm6_step_v2_args_size_c") result(sz)
      import :: c_int32_t
      integer(c_int32_t) :: sz
    end function kdm6_step_v2_args_size_c

    function kdm6_step_v2_c(args) &
        bind(C, name="kdm6_step_v2_c") result(rc)
      import :: c_int, kdm6_step_v2_args_t
      type(kdm6_step_v2_args_t), intent(in) :: args
      integer(c_int) :: rc
    end function kdm6_step_v2_c

    function kdm6_step_c( &
        th, qv, qc, qr, qi, qs, qg, &
        nccn, nc, ni, nr, bg, &
        rho, pii, p, delz, &
        im, kme, jme, dt, &
        param_grad_flags, value_only, &
        th_out, qv_out, qc_out, qr_out, &
        qi_out, qs_out, qg_out, &
        nccn_out, nc_out, ni_out, nr_out, bg_out, &
        handle, &
        xland, ncmin_land, ncmin_sea, &
        rain_increment, snow_increment, graupel_increment, &
        rhog_out &
      ) bind(C, name="kdm6_step_c") result(rc)
      import :: c_int, c_double, c_float, c_ptr
      real(c_float), intent(in)  :: th(*), qv(*), qc(*), qr(*)
      real(c_float), intent(in)  :: qi(*), qs(*), qg(*)
      real(c_float), intent(in)  :: nccn(*), nc(*), ni(*), nr(*), bg(*)
      real(c_float), intent(in)  :: rho(*), pii(*), p(*), delz(*)
      integer(c_int), value       :: im, kme, jme
      real(c_double), value       :: dt
      integer(c_int), value       :: param_grad_flags, value_only
      real(c_float), intent(inout) :: th_out(*), qv_out(*), qc_out(*), qr_out(*)
      real(c_float), intent(inout) :: qi_out(*), qs_out(*), qg_out(*)
      real(c_float), intent(inout) :: nccn_out(*), nc_out(*), ni_out(*), nr_out(*), bg_out(*)
      type(c_ptr), intent(out)    :: handle
      ! Phase 3 ABI extension. xland is (im, jme) float*, may be NULL.
      real(c_float), intent(in)  :: xland(*)
      real(c_double), value       :: ncmin_land, ncmin_sea
      ! Sedimentation surface increments (im, jme) float* [mm], caller-allocated.
      real(c_float), intent(inout) :: rain_increment(*), snow_increment(*), graupel_increment(*)
      ! Graupel density (im, kme, jme) [kg m^-3] → WRF diag_rhog/RHOPO3D.
      real(c_float), intent(inout) :: rhog_out(*)
      integer(c_int)              :: rc
    end function kdm6_step_c

    ! [DA] fp64 DA adjoint forward (kdm6ad+da.md 0.1.A): same physics at
    ! float64 with a gradient graph. Packed layout = the derivative-buffer
    ! convention: state REAL(8) x(im,kme,jme,12) field order th,qv,qc,qr,qi,
    ! qs,qg,nccn,nc,ni,nr,bg; forcing REAL(8) f(im,kme,jme,4) order rho,pii,
    ! p,delz. value_only=0 -> handle for kdm6_handle_vjp_c/jvp_c (true-fp64,
    ! finite at the ice corners where the f32 graph NaNs); value_only=1 ->
    ! handle = C_NULL_PTR. Additive: the operational f32 path is untouched.
    function kdm6_step_ad_c( &
        state_in_packed, forcing_packed, &
        im, kme, jme, dt, value_only, &
        state_out_packed, handle, &
        xland, ncmin_land, ncmin_sea &
      ) bind(C, name="kdm6_step_ad_c") result(rc)
      import :: c_int, c_double, c_float, c_ptr
      real(c_double), intent(in)  :: state_in_packed(*)
      real(c_double), intent(in)  :: forcing_packed(*)
      integer(c_int), value       :: im, kme, jme
      real(c_double), value       :: dt
      integer(c_int), value       :: value_only
      real(c_double), intent(inout) :: state_out_packed(*)
      type(c_ptr), intent(out)    :: handle
      real(c_float), intent(in)  :: xland(*)
      real(c_double), value       :: ncmin_land, ncmin_sea
      integer(c_int)              :: rc
    end function kdm6_step_ad_c

    function kdm6_step_ad_variant_c( &
        state_in_packed, forcing_packed, &
        im, kme, jme, dt, value_only, &
        state_out_packed, handle, &
        xland, ncmin_land, ncmin_sea, physics_variant &
      ) bind(C, name="kdm6_step_ad_variant_c") result(rc)
      import :: c_int, c_int32_t, c_double, c_float, c_ptr
      real(c_double), intent(in)  :: state_in_packed(*)
      real(c_double), intent(in)  :: forcing_packed(*)
      integer(c_int), value       :: im, kme, jme
      real(c_double), value       :: dt
      integer(c_int), value       :: value_only
      real(c_double), intent(inout) :: state_out_packed(*)
      type(c_ptr), intent(out)    :: handle
      real(c_float), intent(in)  :: xland(*)
      real(c_double), value       :: ncmin_land, ncmin_sea
      integer(c_int32_t), value   :: physics_variant
      integer(c_int)              :: rc
    end function kdm6_step_ad_variant_c

    function kdm6_step_ad_number_c( &
        state_in_packed, forcing_packed, &
        im, kme, jme, dt, value_only, &
        state_out_packed, handle, &
        xland, ncmin_land, ncmin_sea, physics_variant, dry_number &
      ) bind(C, name="kdm6_step_ad_number_c") result(rc)
      import :: c_int, c_int32_t, c_int64_t, c_double, c_float, c_ptr
      real(c_double), intent(in)  :: state_in_packed(*)
      real(c_double), intent(in)  :: forcing_packed(*)
      integer(c_int), value       :: im, kme, jme
      real(c_double), value       :: dt
      integer(c_int), value       :: value_only
      real(c_double), intent(inout) :: state_out_packed(*)
      type(c_ptr), intent(out)    :: handle
      real(c_float), intent(in)  :: xland(*)
      real(c_double), value       :: ncmin_land, ncmin_sea
      integer(c_int32_t), value   :: physics_variant
      integer(c_int64_t), value   :: dry_number
      integer(c_int)              :: rc
    end function kdm6_step_ad_number_c

    ! Independent state+forcing fp64 DA forward. Packed arrays are field-major
    ! in Fortran (im,kme,jme,12/4) order; physics_variant and dry_number match
    ! the selectors on kdm6_step_ad_number_c.
    function kdm6_step_ad_state_forcing_c( &
        state_in_packed, forcing_packed, &
        im, kme, jme, dt, value_only, &
        state_out_packed, handle, &
        xland, ncmin_land, ncmin_sea, physics_variant, dry_number &
      ) bind(C, name="kdm6_step_ad_state_forcing_c") result(rc)
      import :: c_int, c_int32_t, c_int64_t, c_double, c_float, c_ptr
      real(c_double), intent(in)  :: state_in_packed(*)
      real(c_double), intent(in)  :: forcing_packed(*)
      integer(c_int), value       :: im, kme, jme
      real(c_double), value       :: dt
      integer(c_int), value       :: value_only
      real(c_double), intent(inout) :: state_out_packed(*)
      type(c_ptr), intent(out)    :: handle
      real(c_float), intent(in)   :: xland(*)
      real(c_double), value       :: ncmin_land, ncmin_sea
      integer(c_int32_t), value   :: physics_variant
      integer(c_int64_t), value   :: dry_number
      integer(c_int)              :: rc
    end function kdm6_step_ad_state_forcing_c

    function kdm6_handle_vjp_c(h, u_packed, grad_out_packed) &
        bind(C, name="kdm6_handle_vjp_c") result(rc)
      import :: c_int, c_double, c_float, c_ptr
      type(c_ptr),    value       :: h
      real(c_double), intent(in)  :: u_packed(*)
      real(c_double), intent(inout) :: grad_out_packed(*)
      integer(c_int)              :: rc
    end function kdm6_handle_vjp_c

    function kdm6_handle_jvp_c(h, v_packed, tangent_out_packed) &
        bind(C, name="kdm6_handle_jvp_c") result(rc)
      import :: c_int, c_double, c_float, c_ptr
      type(c_ptr),    value       :: h
      real(c_double), intent(in)  :: v_packed(*)
      real(c_double), intent(inout) :: tangent_out_packed(*)
      integer(c_int)              :: rc
    end function kdm6_handle_jvp_c

    function kdm6_handle_state_forcing_vjp_c(h, u_packed, &
                                               state_grad_packed, forcing_grad_packed) &
        bind(C, name="kdm6_handle_state_forcing_vjp_c") result(rc)
      import :: c_int, c_double, c_ptr
      type(c_ptr), value           :: h
      real(c_double), intent(in)   :: u_packed(*)
      real(c_double), intent(inout)  :: state_grad_packed(*), forcing_grad_packed(*)
      integer(c_int)               :: rc
    end function kdm6_handle_state_forcing_vjp_c

    function kdm6_handle_state_forcing_jvp_c(h, state_direction_packed, &
                                               forcing_direction_packed, tangent_out_packed) &
        bind(C, name="kdm6_handle_state_forcing_jvp_c") result(rc)
      import :: c_int, c_double, c_ptr
      type(c_ptr), value           :: h
      real(c_double), intent(in)   :: state_direction_packed(*)
      real(c_double), intent(in)   :: forcing_direction_packed(*)
      real(c_double), intent(inout)  :: tangent_out_packed(*)
      integer(c_int)               :: rc
    end function kdm6_handle_state_forcing_jvp_c

    function kdm6_handle_close_c(h) &
        bind(C, name="kdm6_handle_close_c") result(rc)
      import :: c_int, c_ptr
      type(c_ptr), value :: h
      integer(c_int)     :: rc
    end function kdm6_handle_close_c

    ! Pointer-nulling close: hp is passed BY REFERENCE (no VALUE), so the C side
    ! receives kdm6_handle_t** and can reset the caller's c_ptr to C_NULL_PTR.
    function kdm6_handle_closep_c(hp) &
        bind(C, name="kdm6_handle_closep_c") result(rc)
      import :: c_int, c_ptr
      type(c_ptr), intent(inout) :: hp
      integer(c_int)             :: rc
    end function kdm6_handle_closep_c
  end interface

contains

  !
  ! Fortran-friendly 래퍼 — assumed-shape array를 받아 contiguous 가정 후
  ! C ABI에 위임. KIM-meso 측은 (ims:ime, kms:kme, jms:jme) 배열을 그대로 전달.
  !
  function kdm6_step( &
      th, qv, qc, qr, qi, qs, qg, &
      nccn, nc, ni, nr, bg, &
      rho, pii, p, delz, &
      im, kme, jme, dt, &
      param_grad_flags, value_only, &
      th_out, qv_out, qc_out, qr_out, &
      qi_out, qs_out, qg_out, &
      nccn_out, nc_out, ni_out, nr_out, bg_out, &
      handle, &
      xland, ncmin_land, ncmin_sea, &
      rain_increment, snow_increment, graupel_increment, &
      rhog_out &
    ) result(rc)
    real(c_float), intent(in),  contiguous :: th(:,:,:), qv(:,:,:), qc(:,:,:), qr(:,:,:)
    real(c_float), intent(in),  contiguous :: qi(:,:,:), qs(:,:,:), qg(:,:,:)
    real(c_float), intent(in),  contiguous :: nccn(:,:,:), nc(:,:,:), ni(:,:,:), nr(:,:,:), bg(:,:,:)
    real(c_float), intent(in),  contiguous :: rho(:,:,:), pii(:,:,:), p(:,:,:), delz(:,:,:)
    integer(c_int), intent(in)              :: im, kme, jme
    real(c_double), intent(in)              :: dt
    integer(c_int), intent(in)              :: param_grad_flags, value_only
    real(c_float), intent(inout), contiguous :: th_out(:,:,:), qv_out(:,:,:), qc_out(:,:,:), qr_out(:,:,:)
    real(c_float), intent(inout), contiguous :: qi_out(:,:,:), qs_out(:,:,:), qg_out(:,:,:)
    real(c_float), intent(inout), contiguous :: nccn_out(:,:,:), nc_out(:,:,:), ni_out(:,:,:), nr_out(:,:,:)
    real(c_float), intent(inout), contiguous :: bg_out(:,:,:)
    type(c_ptr),    intent(out)             :: handle
    ! Phase 3 ABI extension: land/sea mask + per-regime ncmin scalars.
    real(c_float), intent(in),  contiguous :: xland(:,:)
    real(c_double), intent(in)              :: ncmin_land, ncmin_sea
    ! Sedimentation surface increments (im, jme) [mm] — caller-allocated.
    real(c_float), intent(inout), contiguous :: rain_increment(:,:)
    real(c_float), intent(inout), contiguous :: snow_increment(:,:)
    real(c_float), intent(inout), contiguous :: graupel_increment(:,:)
    ! Graupel density (im, kme, jme) [kg m^-3] → WRF diag_rhog/RHOPO3D.
    real(c_float), intent(inout), contiguous :: rhog_out(:,:,:)
    integer(c_int)                          :: rc

    rc = kdm6_step_c( &
      th, qv, qc, qr, qi, qs, qg, &
      nccn, nc, ni, nr, bg, &
      rho, pii, p, delz, &
      im, kme, jme, dt, &
      param_grad_flags, value_only, &
      th_out, qv_out, qc_out, qr_out, &
      qi_out, qs_out, qg_out, &
      nccn_out, nc_out, ni_out, nr_out, bg_out, &
      handle, &
      xland, real(ncmin_land, c_double), real(ncmin_sea, c_double), &
      rain_increment, snow_increment, graupel_increment, &
      rhog_out)
  end function kdm6_step

  ! [DA] fp64 DA adjoint forward — Fortran-friendly wrapper over kdm6_step_ad_c.
  ! state(im,kme,jme,12) field order th,qv,qc,qr,qi,qs,qg,nccn,nc,ni,nr,bg;
  ! forcing(im,kme,jme,4) order rho,pii,p,delz. value_only=0 -> live handle
  ! for kdm6_handle_vjp/jvp (true-fp64 adjoints); value_only=1 -> C_NULL_PTR.
  ! xland is REQUIRED here (hosts always have XLAND); the C ABI's NULL-xland
  ! default path is reachable from C callers only (Codex review finding 3).
  function kdm6_step_ad( &
      state_in, forcing, &
      im, kme, jme, dt, value_only, &
      state_out, handle, &
      xland, ncmin_land, ncmin_sea &
    ) result(rc)
    real(c_double), intent(in),  contiguous :: state_in(:,:,:,:)
    real(c_double), intent(in),  contiguous :: forcing(:,:,:,:)
    integer(c_int), intent(in)              :: im, kme, jme
    real(c_double), intent(in)              :: dt
    integer(c_int), intent(in)              :: value_only
    real(c_double), intent(inout), contiguous :: state_out(:,:,:,:)
    type(c_ptr),    intent(out)             :: handle
    real(c_float),  intent(in),  contiguous :: xland(:,:)
    real(c_double), intent(in)              :: ncmin_land, ncmin_sea
    integer(c_int)                          :: rc
    rc = kdm6_step_ad_c(state_in, forcing, im, kme, jme, dt, value_only, &
                        state_out, handle, xland, ncmin_land, ncmin_sea)
  end function kdm6_step_ad

  function kdm6_step_ad_variant( &
      state_in, forcing, &
      im, kme, jme, dt, value_only, &
      state_out, handle, &
      xland, ncmin_land, ncmin_sea, physics_variant &
    ) result(rc)
    real(c_double), intent(in),  contiguous :: state_in(:,:,:,:)
    real(c_double), intent(in),  contiguous :: forcing(:,:,:,:)
    integer(c_int), intent(in)              :: im, kme, jme
    real(c_double), intent(in)              :: dt
    integer(c_int), intent(in)              :: value_only
    real(c_double), intent(inout), contiguous :: state_out(:,:,:,:)
    type(c_ptr),    intent(out)             :: handle
    real(c_float),  intent(in),  contiguous :: xland(:,:)
    real(c_double), intent(in)              :: ncmin_land, ncmin_sea
    integer(c_int32_t), intent(in)          :: physics_variant
    integer(c_int)                          :: rc
    rc = kdm6_step_ad_variant_c(state_in, forcing, im, kme, jme, dt, value_only, &
                                state_out, handle, xland, ncmin_land, ncmin_sea, &
                                physics_variant)
  end function kdm6_step_ad_variant

  function kdm6_step_ad_number( &
      state_in, forcing, &
      im, kme, jme, dt, value_only, &
      state_out, handle, &
      xland, ncmin_land, ncmin_sea, physics_variant, dry_number &
    ) result(rc)
    real(c_double), intent(in),  contiguous :: state_in(:,:,:,:)
    real(c_double), intent(in),  contiguous :: forcing(:,:,:,:)
    integer(c_int), intent(in)              :: im, kme, jme
    real(c_double), intent(in)              :: dt
    integer(c_int), intent(in)              :: value_only
    real(c_double), intent(inout), contiguous :: state_out(:,:,:,:)
    type(c_ptr),    intent(out)             :: handle
    real(c_float),  intent(in),  contiguous :: xland(:,:)
    real(c_double), intent(in)              :: ncmin_land, ncmin_sea
    integer(c_int32_t), intent(in)          :: physics_variant
    integer(c_int64_t), intent(in)          :: dry_number
    integer(c_int)                          :: rc
    rc = kdm6_step_ad_number_c(state_in, forcing, im, kme, jme, dt, value_only, &
                               state_out, handle, xland, ncmin_land, ncmin_sea, &
                               physics_variant, dry_number)
  end function kdm6_step_ad_number

  ! Fortran-friendly independent fp64 state+forcing forward. The last
  ! dimensions are field-major: state (im,kme,jme,12), forcing
  ! (im,kme,jme,4), with the same field order as kdm6_step_ad_number.
  ! XLAND is required. Reject shape mismatches before entering C and leave a
  ! deterministic NULL handle on every local error path.
  function kdm6_step_ad_state_forcing( &
      state_in, forcing, &
      im, kme, jme, dt, value_only, &
      state_out, handle, &
      xland, ncmin_land, ncmin_sea, physics_variant, dry_number &
    ) result(rc)
    real(c_double), intent(in), contiguous :: state_in(:,:,:,:)
    real(c_double), intent(in), contiguous :: forcing(:,:,:,:)
    integer(c_int), intent(in)              :: im, kme, jme
    real(c_double), intent(in)              :: dt
    integer(c_int), intent(in)              :: value_only
    real(c_double), intent(inout), contiguous :: state_out(:,:,:,:)
    type(c_ptr), intent(out)                :: handle
    real(c_float), intent(in), contiguous  :: xland(:,:)
    real(c_double), intent(in)              :: ncmin_land, ncmin_sea
    integer(c_int32_t), intent(in)          :: physics_variant
    integer(c_int64_t), intent(in)          :: dry_number
    integer(c_int)                          :: rc

    handle = c_null_ptr
    rc = KDM6_ERR_INVALID_DIM
    if (im <= 0_c_int .or. kme <= 0_c_int .or. jme <= 0_c_int) return
    if (size(state_in,1) /= im .or. size(state_in,2) /= kme .or. &
        size(state_in,3) /= jme .or. size(state_in,4) /= 12) return
    if (size(forcing,1) /= im .or. size(forcing,2) /= kme .or. &
        size(forcing,3) /= jme .or. size(forcing,4) /= 4) return
    if (size(state_out,1) /= im .or. size(state_out,2) /= kme .or. &
        size(state_out,3) /= jme .or. size(state_out,4) /= 12) return
    if (size(xland,1) /= im .or. size(xland,2) /= jme) return

    rc = kdm6_step_ad_state_forcing_c( &
      state_in, forcing, im, kme, jme, dt, value_only, &
      state_out, handle, xland, ncmin_land, ncmin_sea, physics_variant, dry_number)
  end function kdm6_step_ad_state_forcing

  function kdm6_handle_vjp(h, u_packed, grad_out_packed) result(rc)
    type(c_ptr),    intent(in)              :: h
    real(c_double), intent(in),  contiguous :: u_packed(:)
    real(c_double), intent(inout), contiguous :: grad_out_packed(:)
    integer(c_int)                          :: rc
    rc = kdm6_handle_vjp_c(h, u_packed, grad_out_packed)
  end function kdm6_handle_vjp

  function kdm6_handle_jvp(h, v_packed, tangent_out_packed) result(rc)
    type(c_ptr),    intent(in)              :: h
    real(c_double), intent(in),  contiguous :: v_packed(:)
    real(c_double), intent(inout), contiguous :: tangent_out_packed(:)
    integer(c_int)                          :: rc
    rc = kdm6_handle_jvp_c(h, v_packed, tangent_out_packed)
  end function kdm6_handle_jvp

  ! Joint derivatives use caller-sized flat buffers, like the existing
  ! state-only handle wrappers. Their lengths must satisfy the C ABI contract:
  ! u/tangent = 12*im*kme*jme; state directions/gradients use that same size;
  ! forcing directions/gradients = 4*im*kme*jme. The handle owns the dimensions.
  function kdm6_handle_state_forcing_vjp(h, u_packed, &
                                         state_grad_packed, forcing_grad_packed) result(rc)
    type(c_ptr), intent(in)              :: h
    real(c_double), intent(in), contiguous :: u_packed(:)
    real(c_double), intent(inout), contiguous :: state_grad_packed(:), forcing_grad_packed(:)
    integer(c_int)                        :: rc
    rc = kdm6_handle_state_forcing_vjp_c(h, u_packed, &
                                         state_grad_packed, forcing_grad_packed)
  end function kdm6_handle_state_forcing_vjp

  function kdm6_handle_state_forcing_jvp(h, state_direction_packed, &
                                         forcing_direction_packed, tangent_out_packed) result(rc)
    type(c_ptr), intent(in)               :: h
    real(c_double), intent(in), contiguous :: state_direction_packed(:)
    real(c_double), intent(in), contiguous :: forcing_direction_packed(:)
    real(c_double), intent(inout), contiguous :: tangent_out_packed(:)
    integer(c_int)                         :: rc
    rc = kdm6_handle_state_forcing_jvp_c(h, state_direction_packed, &
                                         forcing_direction_packed, tangent_out_packed)
  end function kdm6_handle_state_forcing_jvp

  ! intent(inout): on return, h is reset to C_NULL_PTR so a stale handle can
  ! never be reused (the C side frees the wrapper). Binds to the pointer-nulling
  ! kdm6_handle_closep_c rather than the by-value form.
  function kdm6_handle_close(h) result(rc)
    type(c_ptr), intent(inout) :: h
    integer(c_int)             :: rc
    rc = kdm6_handle_closep_c(h)
  end function kdm6_handle_close

end module kdm6_iso_c
