#pragma once
//
// KDM6 state vector — Python kdm6_torch/kdm6/state.py와 1:1 정합.
// (B, K) 텐서 layout, 12 prognostic + 4 forcing.
//
#include <torch/torch.h>
#include <array>
#include <cstddef>
#include <functional>

namespace kdm6 {

// ── 12 prognostic 필드 (D8 NamedTuple ↔ C++ struct) ────────────────────────
struct State {
    torch::Tensor th;
    torch::Tensor qv;
    torch::Tensor qc;
    torch::Tensor qr;
    torch::Tensor qi;
    torch::Tensor qs;
    torch::Tensor qg;
    torch::Tensor nccn;
    torch::Tensor nc;
    torch::Tensor ni;
    torch::Tensor nr;
    torch::Tensor bg;

    // 텐서 12개를 순회 가능하게 ─ map_state, state_dot 구현용
    std::array<torch::Tensor*, 12> fields() {
        return {&th, &qv, &qc, &qr, &qi, &qs, &qg, &nccn, &nc, &ni, &nr, &bg};
    }
    std::array<const torch::Tensor*, 12> fields() const {
        return {&th, &qv, &qc, &qr, &qi, &qs, &qg, &nccn, &nc, &ni, &nr, &bg};
    }
};

// ── 4 forcing 필드 (보통 grad off) ─────────────────────────────────────────
struct Forcing {
    torch::Tensor rho;
    torch::Tensor pii;
    torch::Tensor p;
    torch::Tensor delz;

    std::array<torch::Tensor*, 4> fields() {
        return {&rho, &pii, &p, &delz};
    }
    std::array<const torch::Tensor*, 4> fields() const {
        return {&rho, &pii, &p, &delz};
    }
};

// ── state-algebra 헬퍼 ─────────────────────────────────────────────────────
State zeros_like_state(const State& s);
torch::Tensor state_dot(const State& a, const State& b);
State map_state(const State& s, const std::function<torch::Tensor(const torch::Tensor&)>& fn);

// ── Fortran-style array adapter ────────────────────────────────────────────
//
// [C4] Fortran의 (im, kme, jme) 배열을 (B=im*jme, K=kme) 순서의
// owning tensor copy로 변환한다. Fortran strides를 B,K layout으로 정렬하고
// nan/negative 입력 게이트를 적용한 뒤에도 원본 buffer와 alias하지 않는다.
// `requires_grad=true`이면 별도의 owning leaf clone을 생성한다.
//
struct FortranArrayDescriptor {
    const float* th;
    const float* qv;
    const float* qc;
    const float* qr;
    const float* qi;
    const float* qs;
    const float* qg;
    const float* nccn;
    const float* nc;
    const float* ni;
    const float* nr;
    const float* bg;
    int im;
    int kme;
    int jme;
};

// Validate the shape arithmetic used by the Fortran adapter before constructing
// a tensor.  The caller supplies an element size because the forward adapter
// carries float32 buffers while the packed AD adapter carries float64 buffers.
// This is a shape/representability check only; it does not inspect or allocate
// the caller's buffers.
bool fortran_shape_fits(int im, int kme, int jme,
                        std::size_t element_size = sizeof(float)) noexcept;
// Same check for a field-major packed buffer containing `field_count` complete
// Fortran arrays.  In addition to byte representability this bounds field
// offsets used by the packed AD bridge to int64_t before any pointer arithmetic.
bool fortran_packed_shape_fits(
    int im, int kme, int jme, std::size_t element_size,
    std::size_t field_count) noexcept;

State from_fortran_arrays(const FortranArrayDescriptor& d,
                          bool requires_grad = true,
                          bool nan_gate = false,
                          bool clip_neg = false);

Forcing forcing_from_fortran_arrays(const float* rho,
                                    const float* pii,
                                    const float* p,
                                    const float* delz,
                                    int im,
                                    int kme,
                                    int jme);

void to_fortran_arrays(const State& state,
                       int im, int jme,
                       /* output buffers, caller-allocated */
                       float* th_out, float* qv_out, float* qc_out,
                       float* qr_out, float* qi_out, float* qs_out,
                       float* qg_out, float* nccn_out, float* nc_out,
                       float* ni_out, float* nr_out, float* bg_out);

// Copy one (B, K) field tensor back to a Fortran column-major float*(im, kme, jme)
// buffer (same layout convention as to_fortran_arrays). Exposed for threading
// auxiliary diagnostics (e.g. diag_rhog/RHOPO3D) that are not part of State.
void copy_back_to_fortran(const torch::Tensor& flat /*(B, K)*/,
                          int im, int jme,
                          float* out /*(im, kme, jme)*/);

}  // namespace kdm6
