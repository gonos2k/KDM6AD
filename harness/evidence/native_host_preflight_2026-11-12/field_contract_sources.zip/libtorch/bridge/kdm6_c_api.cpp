#include "kdm6_c_api.h"
#include "kdm6/runtime.h"
#include "kdm6/state.h"

#include <ATen/Parallel.h>
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <dlfcn.h>
#include <exception>
#include <memory>
#include <mutex>
#include <cstddef>
#include <cstdint>
#include <fenv.h>
#include <cmath>
#include <limits>

//
// C ABI ↔ C++ 어댑터.
// 모든 C++ 예외는 *catch all* → int 에러 코드로 변환. 절대 외부로 던지지 않음.
//

// The C ABI selector enum (kdm6_c_api.h kdm6_physics_variant) and the internal
// C++ enum (kdm6::PhysicsVariant, coordinator.h) must never diverge:
// kdm6_step_v2_c maps one onto the other by numeric value. Pin them at
// compile time so a drift is a build error, not a silent physics swap.
static_assert(static_cast<uint32_t>(kdm6::PhysicsVariant::Legacy) ==
                  (uint32_t)KDM6_PHYSICS_LEGACY,
              "C/C++ physics-variant enum drift (Legacy)");
static_assert(static_cast<uint32_t>(kdm6::PhysicsVariant::ConservativeInterface) ==
                  (uint32_t)KDM6_PHYSICS_CONSERVATIVE_INTERFACE,
              "C/C++ physics-variant enum drift (ConservativeInterface)");
static_assert(static_cast<uint32_t>(kdm6::PhysicsVariant::ConservativeNormalized) ==
                  (uint32_t)KDM6_PHYSICS_CONSERVATIVE_NORMALIZED,
              "C/C++ physics-variant enum drift (ConservativeNormalized)");

extern "C" struct kdm6_handle_t {
    std::unique_ptr<kdm6::Handle> impl;
    // [DA Phase 3] shape metadata for the packed VJP/JVP ABI:
    // packed layout = field-major sequence of FORTRAN (im,kme,jme) column-major
    // double blocks — same convention as the state arrays (field order =
    // State::fields(): th,qv,qc,qr,qi,qs,qg,nccn,nc,ni,nr,bg). See the
    // unpack/pack helpers below; supersedes the kdm6ad+da.md §6.4 (B,K)-C-order
    // sketch, which a Fortran caller could not fill without internal-layout
    // knowledge (Codex stop-review: wrong for nontrivial tiles).
    int im = 0;
    int kme = 0;
    int jme = 0;
    // dtype of the recorded graph (operational kdm6_step_c → Float32; a future
    // fp64 kdm6_step_ad_c → Float64). u/v are cast to this dtype; gradients
    // computed on an f32 graph carry f32 precision even in double buffers
    // (kdm6ad+da.md §0.1.A — the fp64 DA path is the design default).
    c10::ScalarType dtype = c10::ScalarType::Float;
    bool state_forcing_ad = false;
};

namespace {

bool any_null(std::initializer_list<const void*> ptrs) {
    for (auto p : ptrs) {
        if (!p) return true;
    }
    return false;
}

bool invalid_ncmin(double value) {
    return !std::isfinite(value) || value < 0.0;
}

// The runtime deliberately narrows dt/loops to the operational f32 timestep
// before any rate division.  Preflight the same round-half-up loop domain and
// narrowing here so a finite double that becomes zero, Inf, or an out-of-range
// loop count is reported as INVALID_ARG before tensor work.  Non-positive dt
// remains the documented exact no-op and is therefore exempt from the f32
// positivity check.
bool invalid_operational_dt(double dt) {
    if (!std::isfinite(dt)) return true;
    if (dt <= 0.0) return false;

    const double quotient = dt / kdm6::constants::DTCLDCR;
    const double rounded = quotient + 0.5;  // compute_loops_max round-half-up
    if (!std::isfinite(quotient) || !std::isfinite(rounded) ||
        rounded > static_cast<double>(std::numeric_limits<int>::max())) {
        return true;
    }
    const int loops = std::max(1, static_cast<int>(rounded));
    const double dtcld_raw = dt / static_cast<double>(loops);
    if (dtcld_raw > static_cast<double>(std::numeric_limits<float>::max())) return true;
    const float dtcld = static_cast<float>(dtcld_raw);
    return !std::isfinite(dtcld) || dtcld <= 0.0f;
}

// The operational v1/v2 state is staged as float32 before ncmin is expanded
// over columns.  Reject finite doubles that cannot survive that target-dtype
// conversion; clamping later in runtime.cpp cannot repair an overflowing
// full_like arm because both where arms are materialized first.  Tiny positive
// values may underflow to zero and are still handled by the runtime safety floor.
bool invalid_operational_ncmin(double value) {
    if (invalid_ncmin(value)) return true;
    // Avoid an out-of-range double-to-float conversion before asking whether
    // the staged value is finite; the explicit bound is the representability
    // test and keeps the cast itself within the target type's range.
    if (value > static_cast<double>(std::numeric_limits<float>::max())) return true;
    const float staged = static_cast<float>(value);
    return !std::isfinite(staged);
}

bool invalid_fortran_shape(int im, int kme, int jme,
                           std::size_t element_size = sizeof(float)) {
    return !kdm6::fortran_shape_fits(im, kme, jme, element_size);
}

// libtorch/OpenMP single-thread fence.
//
// libkdm6_c depends on libtorch_cpu, and libtorch_cpu depends on libomp, so a
// bridge constructor alone is not a reliable "before libomp" hook. Keep the
// environment defaults for lazy runtime reads, then also call the libomp API
// directly from the first kdm6_step_c entry before any tensor operation.

__attribute__((constructor))
static void kdm6_singlethread_env_fence() {
    // setenv with overwrite=0 respects external user override.
    setenv("OMP_NUM_THREADS", "1", 0);
    setenv("OMP_THREAD_LIMIT", "1", 0);
    setenv("MKL_NUM_THREADS", "1", 0);
    setenv("VECLIB_MAXIMUM_THREADS", "1", 0);
    setenv("KMP_BLOCKTIME", "0", 0);
    // KMP_DUPLICATE_LIB_OK is intentionally NOT set here: it is caller-owned. Only a
    // process that loads two different OpenMP runtimes needs it; the shipped build
    // loads a single consistent libomp (PR1-B source-free diagnostic). Forcing TRUE
    // would silently mask a genuine duplicate-runtime condition. A caller that truly
    // needs it can still export it (an external value was already respected here).
    // See docs/PR1B_OPENMP_DIAGNOSTIC.md.
}

void call_runtime_setter(const char* name, int value) {
    using setter_t = void (*)(int);
    if (auto* symbol = dlsym(RTLD_DEFAULT, name)) {
        reinterpret_cast<setter_t>(symbol)(value);
    }
}

// Returns true iff libtorch is EFFECTIVELY pinned to a single thread (1 intra-op
// AND 1 inter-op). Bitwise determinism REQUIRES this, so the callers refuse the
// step (KDM6_ERR_THREAD_CONFIG) when it returns false — fail-closed, not the
// former swallow-and-continue. The one-time setup stays in call_once (the set_*
// are idempotent), but the EFFECTIVE-value check runs on EVERY call: a set_* is a
// no-op if a pool already spun up, and an inter-op pool could even appear after a
// first good call. The interop setter throwing is NOT itself failure — a pool that
// is already 1 succeeds; the effective value is the sole source of truth.
// noexcept: this is called OUTSIDE the entry-point try blocks, so any exception
// escaping here would cross the C ABI boundary (undefined behavior). The one-time
// setters run in call_once; the EFFECTIVE getters + final boolean run on EVERY
// call OUTSIDE call_once (a cached result would keep returning true after later
// process-global drift). A setter throwing is not itself failure — the effective
// value is the sole contract (an already-1 inter-op pool succeeds even if the
// setter refused).
bool ensure_libtorch_singlethread() noexcept {
    try {
        static std::once_flag flag;
        std::call_once(flag, []() noexcept {
            try {
                call_runtime_setter("omp_set_dynamic", 0);
                call_runtime_setter("omp_set_num_threads", 1);
                call_runtime_setter("omp_set_max_active_levels", 1);
                call_runtime_setter("kmp_set_blocktime", 0);
                try { at::set_num_threads(1); } catch (...) { /* effective check decides */ }
                try { at::set_num_interop_threads(1); } catch (...) { /* pool already started */ }
                // np4 flaky-NaN forensics: report the EFFECTIVE threading (set_* is a
                // no-op if a pool already spun up before this fence ran).
                fprintf(stderr, "[kdm6ad-diag] intra=%d interop=%d\n",
                        at::get_num_threads(), at::get_num_interop_threads());
                fflush(stderr);
            } catch (...) { /* final effective check below returns false */ }
        });
        bool ok = at::get_num_threads() == 1 && at::get_num_interop_threads() == 1;
#ifdef KDM6_ENABLE_TEST_HOOKS
        // Test-only fault injection (PR1-A): exercise the fail-closed path from the
        // pure-C ABI test, which cannot spin a real >1 thread pool. COMPILED OUT of
        // shipped builds (KDM6_ENABLE_TEST_HOOKS is OFF by default) so the
        // operational dylib never honors this env var. Overrides only THIS call's
        // return (never the cached setup), and requires the EXACT opt-in value "1"
        // (so a stray =0 does not activate it). Touches NO numerical path.
        if (const char* f = getenv("KDM6_TEST_FORCE_THREAD_CONFIG_FAIL");
            f && strcmp(f, "1") == 0) {
            ok = false;
        }
#endif
        return ok;
    } catch (...) {
        return false;
    }
}

// FP-environment fence (Codex deep-review lead, 2026-06-22): libtorch / its BLAS
// backend can set the denormals-flush (FTZ/FZ) and/or rounding bits in the host
// FP control register, and those LEAK back into the WRF Fortran dynamics that runs
// after this ABI call — diverging the multi-step trajectory even though the 12
// microphysics outputs are bitwise per step. Save the caller's FP env on entry and
// restore it on every return path (RAII) so the host dynamics keeps mp37's env.
// AD-safe: this is FP control only, touches no autograd tensor.
struct FpEnvGuard {
    fenv_t saved_;
    FpEnvGuard() { fegetenv(&saved_); }
    ~FpEnvGuard() { fesetenv(&saved_); }
};

}  // anonymous namespace

#ifdef KDM6_NATIVE_SCALAR_CAPTURE
// Historical host compatibility only: the old context callback accepted eight
// by-value C integers for optional moment tracing. This build does not implement
// that tracing; the callback deliberately has no effect on model calculations.
extern "C" KDM6_C_API void kdm6_moment_trace_context_c(int, int, int, int, int, int, int, int) noexcept {}
namespace kdm6 {
extern thread_local const float *scalar_abi_qi, *scalar_abi_ni, *scalar_abi_p, *scalar_abi_den;
extern thread_local int scalar_abi_im, scalar_abi_jme, scalar_abi_kme;
}
        struct AbiIngressGuard {
            AbiIngressGuard(const float* qi, const float* ni, const float* p, const float* den, int im, int jme, int kme) {
                kdm6::scalar_abi_qi = qi; kdm6::scalar_abi_ni = ni; kdm6::scalar_abi_p = p; kdm6::scalar_abi_den = den;
                kdm6::scalar_abi_im = im; kdm6::scalar_abi_jme = jme; kdm6::scalar_abi_kme = kme;
            }
            ~AbiIngressGuard() { kdm6::scalar_abi_qi = kdm6::scalar_abi_ni = kdm6::scalar_abi_p = kdm6::scalar_abi_den = nullptr; }
        };
#endif
extern "C" int kdm6_step_c(
    const float* th, const float* qv, const float* qc, const float* qr,
    const float* qi, const float* qs, const float* qg,
    const float* nccn, const float* nc, const float* ni, const float* nr,
    const float* bg,
    const float* rho, const float* pii, const float* p, const float* delz,
    int im, int kme, int jme, double dt,
    int param_grad_flags, int value_only,
    float* th_out, float* qv_out, float* qc_out, float* qr_out,
    float* qi_out, float* qs_out, float* qg_out,
    float* nccn_out, float* nc_out, float* ni_out, float* nr_out,
    float* bg_out,
    kdm6_handle_t** handle,
    const float* xland,
    double ncmin_land,
    double ncmin_sea,
    float* rain_increment,
    float* snow_increment,
    float* graupel_increment,
    float* rhog_out
) {
    // Defensive ABI: guarantee the output handle is NULL on EVERY error path, so a caller
    // that forgets to check the return code never reads an uninitialized handle.
    if (handle) *handle = nullptr;
    if (im <= 0 || kme <= 0 || jme <= 0 ||
        invalid_fortran_shape(im, kme, jme)) return KDM6_ERR_INVALID_DIM;
    // value_only is a 0/1 flag (0 → derivative handle, 1 → NULL handle). Reject any other
    // value rather than silently treating a stray nonzero (e.g. 2) as value-only.
    if (value_only != 0 && value_only != 1) return KDM6_ERR_INVALID_ARG;
    // Note: `xland` deliberately excluded from null check — it's optional.
    if (any_null({th, qv, qc, qr, qi, qs, qg, nccn, nc, ni, nr, bg,
                  rho, pii, p, delz,
                  th_out, qv_out, qc_out, qr_out, qi_out, qs_out, qg_out,
                  nccn_out, nc_out, ni_out, nr_out, bg_out, handle})) {
        return KDM6_ERR_NULL_POINTER;
    }
    // param_grad_flags is RESERVED (see kdm6_c_api.h): physics-parameter grads are
    // not wired into the forward graph (kdm6_fn uses baked-in constants), so a
    // non-zero flag would silently have no effect. Reject it loudly instead.
    if (param_grad_flags != 0) return KDM6_ERR_NOT_IMPLEMENTED;
    // Match the public Python boundary: dt may be non-positive (the runtime's
    // documented no-op), but NaN/Inf is outside the scalar contract. ncmin is a
    // non-negative regime floor; reject malformed values before any tensor work.
    if (invalid_operational_dt(dt) || invalid_operational_ncmin(ncmin_land) ||
        invalid_operational_ncmin(ncmin_sea))
        return KDM6_ERR_INVALID_ARG;

    // RAII: restore the caller's (Fortran host) FP env on every return path.
    // Defensive ABI hygiene — libtorch/its BLAS backend could set FTZ/DAZ/rounding;
    // verified a no-op on this build (ARM FPCR unchanged), kept to insulate the host dynamics.
    FpEnvGuard kdm6_fpenv_guard;

    // Fail-closed thread fence (PR1-A): single-thread pinning is a precondition
    // for bitwise determinism. Refuse BEFORE any tensor creation — the handle is
    // already NULL (top of function) and no output buffer has been written yet.
    if (!ensure_libtorch_singlethread()) return KDM6_ERR_THREAD_CONFIG;

    try {
#ifdef KDM6_NATIVE_SCALAR_CAPTURE
        AbiIngressGuard abi_ingress(qi, ni, p, rho, im, jme, kme);
#endif
        kdm6::FortranArrayDescriptor desc{
            th, qv, qc, qr, qi, qs, qg, nccn, nc, ni, nr, bg, im, kme, jme};
        // [C4] requires_grad는 value_only=0일 때만 켬
        bool requires_grad = (value_only == 0);
        auto state_in = kdm6::from_fortran_arrays(desc, requires_grad);

        auto forcing = kdm6::forcing_from_fortran_arrays(rho, pii, p, delz, im, kme, jme);

        auto params = kdm6::make_parameters(param_grad_flags);

        // Optional xland → Tensor conversion (state.cpp layout convention):
        // Fortran xland(im, jme) is column-major float*; C-order view is
        // (jme, im); permute({1, 0}) gives (im, jme); reshape to flat
        // (im*jme,) batch matches state batch index = i*jme + j.
        c10::optional<torch::Tensor> xland_t = c10::nullopt;
        if (xland != nullptr) {
            auto opts = torch::TensorOptions().dtype(torch::kFloat32);
            auto view2d = torch::from_blob(const_cast<float*>(xland),
                                           {jme, im}, opts)
                              .permute({1, 0})
                              .contiguous();
            const int64_t ncol = static_cast<int64_t>(im) *
                                 static_cast<int64_t>(jme);
            xland_t = view2d.reshape({ncol});
        }

        auto result = kdm6::kdm6_step(state_in, forcing, params, dt, value_only != 0,
                                      xland_t, ncmin_land, ncmin_sea);

        kdm6::to_fortran_arrays(result.state_out, im, jme,
                                th_out, qv_out, qc_out, qr_out, qi_out, qs_out, qg_out,
                                nccn_out, nc_out, ni_out, nr_out, bg_out);

        // diag_rhog/RHOPO3D — graupel density from the last ProgB (optional out;
        // NULL → discard). Same (im, kme, jme) column-major layout as bg_out.
        // intent(out) contract: when rhog_out is supplied it is ALWAYS written —
        // zeros if the result tensor is (defensively) undefined — so the Fortran
        // caller never copies uninitialized memory into diag_rhog.
        if (rhog_out != nullptr) {
            if (result.rhog.defined()) {
                kdm6::copy_back_to_fortran(result.rhog, im, jme, rhog_out);
            } else {
                const size_t n_rhog = static_cast<size_t>(im) * kme * jme;
                for (size_t idx = 0; idx < n_rhog; ++idx) rhog_out[idx] = 0.0f;
            }
        }

        // Copy-back sedimentation surface increments — (im*jme,) Tensor →
        // Fortran column-major float*(im, jme). Reuses the same (im, jme) ↔
        // batch-flat layout convention as xland staging (state.cpp:67-72):
        //   batch index B = i*jme + j; Fortran memory = (i, j) column-major.
        // So tensor[B] at index i*jme+j maps to fortran[i + im*j].
        auto copy_increment = [im, jme](const torch::Tensor& inc, float* dst) {
            if (dst == nullptr) return;
            auto inc_cpu = inc.contiguous().to(torch::kCPU, torch::kFloat32);
            auto inc_2d = inc_cpu.reshape({im, jme}); // (im, jme) C-order
            const float* src = inc_2d.data_ptr<float>();
            // Transpose to Fortran (im, jme) column-major: dst[i + im*j] = src[i*jme + j]
            for (int i = 0; i < im; ++i) {
                for (int j = 0; j < jme; ++j) {
                    dst[i + im * j] = src[i * jme + j];
                }
            }
        };
        copy_increment(result.rain_increment,    rain_increment);
        copy_increment(result.snow_increment,    snow_increment);
        copy_increment(result.graupel_increment, graupel_increment);

        if (value_only != 0) {
            *handle = nullptr;
        } else {
            auto* h = new kdm6_handle_t{};
            h->impl = std::move(result.handle);
            h->im = im; h->kme = kme; h->jme = jme;
            h->dtype = c10::ScalarType::Float;   // operational f32 graph
            *handle = h;
        }
        return KDM6_OK;
    } catch (const c10::NotImplementedError&) {
        return KDM6_ERR_NOT_IMPLEMENTED;
    } catch (const std::exception& e) {
        std::fprintf(stderr, "kdm6_step_c: %s\n", e.what());
        return KDM6_ERR_INTERNAL;
    } catch (...) {
        std::fprintf(stderr, "kdm6_step_c: unknown non-std exception\n");
        return KDM6_ERR_INTERNAL;
    }
}

#ifdef KDM6_ENABLE_NATIVE_FP64_VALUE_BRIDGE
// Explicit experimental value bridge. The operational entry above is unchanged.
// See docs/NATIVE_FP64_VALUE_BRIDGE.md; this is not an extension of packed AD.
extern "C" int kdm6_native_fp64_value_c(
    const float* th, const float* qv, const float* qc, const float* qr,
    const float* qi, const float* qs, const float* qg,
    const float* nccn, const float* nc, const float* ni, const float* nr,
    const float* bg,
    const float* rho, const float* pii, const float* p, const float* delz,
    int im, int kme, int jme, double dt,
    int param_grad_flags, int value_only,
    float* th_out, float* qv_out, float* qc_out, float* qr_out,
    float* qi_out, float* qs_out, float* qg_out,
    float* nccn_out, float* nc_out, float* ni_out, float* nr_out,
    float* bg_out,
    kdm6_handle_t** handle,
    const float* xland,
    double ncmin_land,
    double ncmin_sea,
    float* rain_increment,
    float* snow_increment,
    float* graupel_increment,
    float* rhog_out
) {
    // Defensive ABI: guarantee the output handle is NULL on EVERY error path, so a caller
    // that forgets to check the return code never reads an uninitialized handle.
    if (handle) *handle = nullptr;
    if (im <= 0 || kme <= 0 || jme <= 0 ||
        invalid_fortran_shape(im, kme, jme)) return KDM6_ERR_INVALID_DIM;
    // This separate experimental entry is forward-only. No AD handle or
    // quantization derivative is provided, including when value_only is zero.
    if (value_only != 1) return KDM6_ERR_INVALID_ARG;
    // Note: `xland` deliberately excluded from null check — it's optional.
    if (any_null({th, qv, qc, qr, qi, qs, qg, nccn, nc, ni, nr, bg,
                  rho, pii, p, delz,
                  th_out, qv_out, qc_out, qr_out, qi_out, qs_out, qg_out,
                  nccn_out, nc_out, ni_out, nr_out, bg_out, handle})) {
        return KDM6_ERR_NULL_POINTER;
    }
    // param_grad_flags is RESERVED (see kdm6_c_api.h): physics-parameter grads are
    // not wired into the forward graph (kdm6_fn uses baked-in constants), so a
    // non-zero flag would silently have no effect. Reject it loudly instead.
    if (param_grad_flags != 0) return KDM6_ERR_NOT_IMPLEMENTED;
    // Match the public Python boundary: dt may be non-positive (the runtime's
    // documented no-op), but NaN/Inf is outside the scalar contract. ncmin is a
    // non-negative regime floor; reject malformed values before any tensor work.
    if (invalid_operational_dt(dt) || invalid_operational_ncmin(ncmin_land) ||
        invalid_operational_ncmin(ncmin_sea))
        return KDM6_ERR_INVALID_ARG;

    // RAII: restore the caller's (Fortran host) FP env on every return path.
    // Defensive ABI hygiene — libtorch/its BLAS backend could set FTZ/DAZ/rounding;
    // verified a no-op on this build (ARM FPCR unchanged), kept to insulate the host dynamics.
    FpEnvGuard kdm6_fpenv_guard;

    // Fail-closed thread fence (PR1-A): single-thread pinning is a precondition
    // for bitwise determinism. Refuse BEFORE any tensor creation — the handle is
    // already NULL (top of function) and no output buffer has been written yet.
    if (!ensure_libtorch_singlethread()) return KDM6_ERR_THREAD_CONFIG;

    try {
#ifdef KDM6_NATIVE_SCALAR_CAPTURE
        AbiIngressGuard abi_ingress(qi, ni, p, rho, im, jme, kme);
#endif
        kdm6::FortranArrayDescriptor desc{
            th, qv, qc, qr, qi, qs, qg, nccn, nc, ni, nr, bg, im, kme, jme};
        // Decode REAL4 storage first; never reinterpret a float buffer as double.
        auto state32 = kdm6::from_fortran_arrays(desc, /*requires_grad=*/false);
        auto state_in = kdm6::map_state(state32, [](const torch::Tensor& value) {
            return value.to(torch::kFloat64);
        });

        auto forcing = kdm6::forcing_from_fortran_arrays(rho, pii, p, delz, im, kme, jme);
        forcing.rho = forcing.rho.to(torch::kFloat64);
        forcing.pii = forcing.pii.to(torch::kFloat64);
        forcing.p = forcing.p.to(torch::kFloat64);
        forcing.delz = forcing.delz.to(torch::kFloat64);

        auto params = kdm6::make_parameters(param_grad_flags);

        // Optional xland → Tensor conversion (state.cpp layout convention):
        // Fortran xland(im, jme) is column-major float*; C-order view is
        // (jme, im); permute({1, 0}) gives (im, jme); reshape to flat
        // (im*jme,) batch matches state batch index = i*jme + j.
        c10::optional<torch::Tensor> xland_t = c10::nullopt;
        if (xland != nullptr) {
            auto opts = torch::TensorOptions().dtype(torch::kFloat32);
            auto view2d = torch::from_blob(const_cast<float*>(xland),
                                           {jme, im}, opts)
                              .permute({1, 0})
                              .contiguous();
            const int64_t ncol = static_cast<int64_t>(im) *
                                 static_cast<int64_t>(jme);
            xland_t = view2d.reshape({ncol});
        }

        auto result = kdm6::kdm6_step(state_in, forcing, params, dt, value_only != 0,
                                      xland_t, ncmin_land, ncmin_sea);

        // Value-only output admission before any REAL4 buffer is written.
        // The existing FP64 physical map is unchanged; overflow at writeback
        // is invalid rather than an implicit clipping/repair operation.
        auto require_finite_real4 = [](const torch::Tensor& value) {
            TORCH_CHECK(torch::isfinite(value).all().item<bool>() &&
                        torch::isfinite(value.to(torch::kFloat32)).all().item<bool>(),
                        "native FP64 value bridge: nonfinite or unrepresentable REAL4 output");
        };
        for (const auto* field : result.state_out.fields()) require_finite_real4(*field);
        require_finite_real4(result.rain_increment);
        require_finite_real4(result.snow_increment);
        require_finite_real4(result.graupel_increment);
        if (result.rhog.defined()) require_finite_real4(result.rhog);

        kdm6::to_fortran_arrays(result.state_out, im, jme,
                                th_out, qv_out, qc_out, qr_out, qi_out, qs_out, qg_out,
                                nccn_out, nc_out, ni_out, nr_out, bg_out);

        // diag_rhog/RHOPO3D — graupel density from the last ProgB (optional out;
        // NULL → discard). Same (im, kme, jme) column-major layout as bg_out.
        // intent(out) contract: when rhog_out is supplied it is ALWAYS written —
        // zeros if the result tensor is (defensively) undefined — so the Fortran
        // caller never copies uninitialized memory into diag_rhog.
        if (rhog_out != nullptr) {
            if (result.rhog.defined()) {
                kdm6::copy_back_to_fortran(result.rhog, im, jme, rhog_out);
            } else {
                const size_t n_rhog = static_cast<size_t>(im) * kme * jme;
                for (size_t idx = 0; idx < n_rhog; ++idx) rhog_out[idx] = 0.0f;
            }
        }

        // Copy-back sedimentation surface increments — (im*jme,) Tensor →
        // Fortran column-major float*(im, jme). Reuses the same (im, jme) ↔
        // batch-flat layout convention as xland staging (state.cpp:67-72):
        //   batch index B = i*jme + j; Fortran memory = (i, j) column-major.
        // So tensor[B] at index i*jme+j maps to fortran[i + im*j].
        auto copy_increment = [im, jme](const torch::Tensor& inc, float* dst) {
            if (dst == nullptr) return;
            auto inc_cpu = inc.contiguous().to(torch::kCPU, torch::kFloat32);
            auto inc_2d = inc_cpu.reshape({im, jme}); // (im, jme) C-order
            const float* src = inc_2d.data_ptr<float>();
            // Transpose to Fortran (im, jme) column-major: dst[i + im*j] = src[i*jme + j]
            for (int i = 0; i < im; ++i) {
                for (int j = 0; j < jme; ++j) {
                    dst[i + im * j] = src[i * jme + j];
                }
            }
        };
        copy_increment(result.rain_increment,    rain_increment);
        copy_increment(result.snow_increment,    snow_increment);
        copy_increment(result.graupel_increment, graupel_increment);

        *handle = nullptr;  // This entry never creates a derivative handle.
        return KDM6_OK;
    } catch (const c10::NotImplementedError&) {
        return KDM6_ERR_NOT_IMPLEMENTED;
    } catch (const std::exception& e) {
        std::fprintf(stderr, "kdm6_native_fp64_value_c: %s\n", e.what());
        return KDM6_ERR_INTERNAL;
    } catch (...) {
        std::fprintf(stderr, "kdm6_native_fp64_value_c: unknown non-std exception\n");
        return KDM6_ERR_INTERNAL;
    }
}
#endif


// ── PR2: stable ABI v2 (docs/PR2_ABI_V2_DESIGN.md) ──────────────────────────
// v2 is ADDITIVE: kdm6_step_c (above) is untouched. kdm6_step_v2_c reads the
// options struct and calls the SAME internal physics core (kdm6::kdm6_step),
// so v1 and v2 are bitwise-equivalent (pinned by test_c_abi_v2_matches_v1).

extern "C" int kdm6_get_abi_version_c(void) { return (int)KDM6_ABI_VERSION; }

extern "C" uint32_t kdm6_step_v2_args_size_c(void) {
    return (uint32_t)sizeof(kdm6_step_v2_args);
}

extern "C" int kdm6_step_v2_c(const kdm6_step_v2_args* args) {
    if (args == nullptr) return KDM6_ERR_NULL_POINTER;
    // FRAMING read-order (design §4): read struct_size (offset 0) FIRST and
    // reject below the two framing fields BEFORE abi_version (offset 4) is read.
    // A short caller owns only the framing bytes, not a full aligned C++
    // options object. Bytewise reads keep that prefix contract well-defined.
    const auto* bytes = reinterpret_cast<const unsigned char*>(args);
    uint32_t struct_size = 0;
    std::memcpy(&struct_size, bytes, sizeof(struct_size));
    if (struct_size < KDM6_STEP_V2_MIN_SIZE) return KDM6_ERR_INVALID_ARG;
    uint32_t abi_version = 0;
    std::memcpy(&abi_version, bytes + offsetof(kdm6_step_v2_args, abi_version),
                sizeof(abi_version));
    if (abi_version != KDM6_ABI_VERSION) return KDM6_ERR_INVALID_ARG;
    // struct_size must cover every REQUIRED field (everything up to the first
    // optional field, `xland`). The optional tail may be absent (older caller).
    if (struct_size < (uint32_t)offsetof(kdm6_step_v2_args, xland))
        return KDM6_ERR_INVALID_ARG;

    // Read an optional field ONLY if struct_size extends through it — never
    // read past min(struct_size, sizeof) (design §4).
#define KDM6_V2_HAS(f) \
    (struct_size >= (uint32_t)(offsetof(kdm6_step_v2_args, f) + sizeof(args->f)))
    const float* xland = KDM6_V2_HAS(xland) ? args->xland : nullptr;
    double ncmin_land = KDM6_V2_HAS(ncmin_land) ? args->ncmin_land : 0.0;
    double ncmin_sea  = KDM6_V2_HAS(ncmin_sea)  ? args->ncmin_sea  : 0.0;
    float* rain_increment    = KDM6_V2_HAS(rain_increment)    ? args->rain_increment    : nullptr;
    float* snow_increment    = KDM6_V2_HAS(snow_increment)    ? args->snow_increment    : nullptr;
    float* graupel_increment = KDM6_V2_HAS(graupel_increment) ? args->graupel_increment : nullptr;
    float* rhog_out          = KDM6_V2_HAS(rhog_out)          ? args->rhog_out          : nullptr;
    // conservative-interface-v1 selector: absent field ⇒ legacy (the append-
    // only contract every pre-existing caller relies on).
    const uint32_t physics_variant =
        KDM6_V2_HAS(physics_variant) ? args->physics_variant
                                     : (uint32_t)KDM6_PHYSICS_LEGACY;
    const int64_t dry_number = KDM6_V2_HAS(dry_number) ? args->dry_number : 0;
#undef KDM6_V2_HAS

    const int im = args->im, kme = args->kme, jme = args->jme;
    const int value_only = args->value_only;
    kdm6_handle_t** handle = args->handle;

    // For a matching, sufficiently framed record, use the same validation
    // precedence as kdm6_step_c and clear the safely located handle before
    // returning any pre-work refusal.  Version/short-framing returns above
    // intentionally cannot make a pointer postcondition about unknown layout.
    if (handle) *handle = nullptr;
    if (im <= 0 || kme <= 0 || jme <= 0 ||
        invalid_fortran_shape(im, kme, jme)) return KDM6_ERR_INVALID_DIM;
    if (value_only != 0 && value_only != 1) return KDM6_ERR_INVALID_ARG;
    if (any_null({args->th, args->qv, args->qc, args->qr, args->qi, args->qs,
                  args->qg, args->nccn, args->nc, args->ni, args->nr, args->bg,
                  args->rho, args->pii, args->p, args->delz,
                  args->th_out, args->qv_out, args->qc_out, args->qr_out,
                  args->qi_out, args->qs_out, args->qg_out, args->nccn_out,
                  args->nc_out, args->ni_out, args->nr_out, args->bg_out,
                  handle})) {
        return KDM6_ERR_NULL_POINTER;
    }
    if (args->param_grad_flags != 0) return KDM6_ERR_NOT_IMPLEMENTED;
    // Required dt is always covered by the v2 required prefix. The ncmin fields
    // are optional and default to zero when absent, so validate the values after
    // the size-gated reads above and before the thread/tensor boundary.
    if (invalid_operational_dt(args->dt) || invalid_operational_ncmin(ncmin_land) ||
        invalid_operational_ncmin(ncmin_sea))
        return KDM6_ERR_INVALID_ARG;
    // Variant validation: fail-loud BEFORE the thread fence and any tensor
    // work; *handle is already fail-closed to NULL above and no output has
    // been written. Unknown values must never fall back to legacy silently.
    if (physics_variant != (uint32_t)KDM6_PHYSICS_LEGACY &&
        physics_variant != (uint32_t)KDM6_PHYSICS_CONSERVATIVE_INTERFACE &&
        physics_variant != (uint32_t)KDM6_PHYSICS_CONSERVATIVE_NORMALIZED)
        return KDM6_ERR_INVALID_ARG;
    if (dry_number < 0 || dry_number > 1) return KDM6_ERR_INVALID_ARG;
    if (dry_number == 1 && value_only == 0) return KDM6_ERR_NOT_IMPLEMENTED;
    // Validated selector → C++ PhysicsOptions, threaded into kdm6::kdm6_step
    // below. 0 keeps the legacy default (bitwise-identical); 1 swaps the
    // sedimentation substeps for the conservative-interface pair.
    kdm6::PhysicsOptions physics;
    physics.variant = static_cast<kdm6::PhysicsVariant>(physics_variant);

    FpEnvGuard kdm6_fpenv_guard;
    if (!ensure_libtorch_singlethread()) return KDM6_ERR_THREAD_CONFIG;

    try {
#ifdef KDM6_NATIVE_SCALAR_CAPTURE
        AbiIngressGuard abi_ingress(args->qi, args->ni, args->p, args->rho, im, jme, kme);
#endif
        kdm6::FortranArrayDescriptor desc{
            args->th, args->qv, args->qc, args->qr, args->qi, args->qs, args->qg,
            args->nccn, args->nc, args->ni, args->nr, args->bg, im, kme, jme};
        bool requires_grad = (value_only == 0);
        auto state_in = kdm6::from_fortran_arrays(desc, requires_grad);
        auto forcing = kdm6::forcing_from_fortran_arrays(
            args->rho, args->pii, args->p, args->delz, im, kme, jme);
        auto params = kdm6::make_parameters(args->param_grad_flags);

        c10::optional<torch::Tensor> xland_t = c10::nullopt;
        if (xland != nullptr) {
            auto opts = torch::TensorOptions().dtype(torch::kFloat32);
            auto view2d = torch::from_blob(const_cast<float*>(xland),
                                           {jme, im}, opts)
                              .permute({1, 0}).contiguous();
            const int64_t ncol = static_cast<int64_t>(im) *
                                 static_cast<int64_t>(jme);
            xland_t = view2d.reshape({ncol});
        }

        auto result = kdm6::kdm6_step(state_in, forcing, params, args->dt,
                                      value_only != 0, xland_t,
                                      ncmin_land, ncmin_sea, physics,
                                      dry_number == 1);

        // Reserve the fallible handle allocation before touching any caller
        // output.  This keeps the common allocation failure path fully
        // pre-output; the public v2 contract still deliberately treats later
        // internal failures as non-transactional (caller buffers cannot be
        // rolled back without a second output staging framework).
        std::unique_ptr<kdm6_handle_t> output_handle;
        if (value_only == 0) {
            output_handle = std::make_unique<kdm6_handle_t>();
            output_handle->impl = std::move(result.handle);
            output_handle->im = im;
            output_handle->kme = kme;
            output_handle->jme = jme;
            output_handle->dtype = c10::ScalarType::Float;
        }

        kdm6::to_fortran_arrays(result.state_out, im, jme,
            args->th_out, args->qv_out, args->qc_out, args->qr_out, args->qi_out,
            args->qs_out, args->qg_out, args->nccn_out, args->nc_out,
            args->ni_out, args->nr_out, args->bg_out);

        if (rhog_out != nullptr) {
            if (result.rhog.defined()) {
                kdm6::copy_back_to_fortran(result.rhog, im, jme, rhog_out);
            } else {
                const size_t n_rhog = static_cast<size_t>(im) * kme * jme;
                for (size_t idx = 0; idx < n_rhog; ++idx) rhog_out[idx] = 0.0f;
            }
        }

        auto copy_increment = [im, jme](const torch::Tensor& inc, float* dst) {
            if (dst == nullptr) return;
            auto inc_cpu = inc.contiguous().to(torch::kCPU, torch::kFloat32);
            auto inc_2d = inc_cpu.reshape({im, jme});
            const float* src = inc_2d.data_ptr<float>();
            for (int i = 0; i < im; ++i)
                for (int j = 0; j < jme; ++j)
                    dst[i + im * j] = src[i * jme + j];
        };
        copy_increment(result.rain_increment,    rain_increment);
        copy_increment(result.snow_increment,    snow_increment);
        copy_increment(result.graupel_increment, graupel_increment);

        if (value_only != 0) {
            *handle = nullptr;
        } else {
            *handle = output_handle.release();
        }
        return KDM6_OK;
    } catch (const c10::NotImplementedError&) {
        return KDM6_ERR_NOT_IMPLEMENTED;
    } catch (const std::exception& e) {
        std::fprintf(stderr, "kdm6_step_v2_c: %s\n", e.what());
        return KDM6_ERR_INTERNAL;
    } catch (...) {
        std::fprintf(stderr, "kdm6_step_v2_c: unknown non-std exception\n");
        return KDM6_ERR_INTERNAL;
    }
}

namespace {

// PACKED DERIVATIVE LAYOUT (Codex stop-review fix — "wrong for nontrivial tiles"):
// the packed u/v/grad/tangent buffers use the SAME convention as every other
// array in this ABI — a field-major sequence of FORTRAN (im, kme, jme)
// COLUMN-MAJOR double blocks (field order = State::fields(): th,qv,qc,qr,qi,
// qs,qg,nccn,nc,ni,nr,bg; per-field offset = field*im*kme*jme; within a field,
// element (i,k,j) sits at i + im*k + im*kme*j, exactly like the state arrays).
// The bridge performs the same (jme,kme,im)->(B=i*jme+j, K) staging as
// from_blob_3d (state.cpp) and its inverse on the way out — a Fortran caller
// fills these buffers exactly like its state arrays, no internal-layout
// knowledge required. (The previous draft consumed the internal (B,K) C-order
// directly, which only coincided with this for im=jme=1 tiles.)
kdm6::State unpack_packed_state(const double* packed, int im, int kme, int jme,
                                c10::ScalarType dtype) {
    const int64_t N = static_cast<int64_t>(im) * kme * jme;
    kdm6::State s;
    auto fp = s.fields();
    auto opts = torch::TensorOptions().dtype(torch::kFloat64);
    for (size_t f = 0; f < fp.size(); ++f) {
        // Fortran column-major (im,kme,jme) == C-order (jme,kme,im)
        auto view3d = torch::from_blob(
            const_cast<double*>(packed) + static_cast<int64_t>(f) * N,
            {jme, kme, im}, opts)
                          .permute({2, 1, 0});            // -> (im,kme,jme) logical
        auto flat = view3d.permute({0, 2, 1})              // -> (im,jme,kme)
                          .reshape({static_cast<int64_t>(im) * jme, kme});
        *fp[f] = flat.clone().to(dtype);                   // (B=i*jme+j, K)
    }
    return s;
}

// State (B,K) → packed Fortran column-major double blocks (always written fp64 —
// the DA-side containers; an f32-graph gradient keeps f32 PRECISION inside them).
// Mirrors copy_back_to_fortran (state.cpp) at double precision.
void pack_packed_state(const kdm6::State& s, double* packed,
                       int im, int kme, int jme) {
    const int64_t N = static_cast<int64_t>(im) * kme * jme;
    auto fp = const_cast<kdm6::State&>(s).fields();
    for (size_t f = 0; f < fp.size(); ++f) {
        auto t = fp[f]->detach().to(torch::kFloat64);
        TORCH_CHECK(t.numel() == N, "packed field ", f, " numel mismatch");
        auto fortran_order = t.reshape({im, jme, kme})     // (B,K)->(im,jme,K)
                                 .permute({0, 2, 1})       // -> (im,kme,jme) logical
                                 .permute({2, 1, 0})       // -> (jme,kme,im) C-order
                                 .contiguous();            //  == Fortran col-major bytes
        std::memcpy(packed + static_cast<int64_t>(f) * N,
                    fortran_order.data_ptr<double>(), sizeof(double) * N);
    }
}

}  // namespace

namespace {

// forcing_packed (4 Fortran col-major double blocks: rho,pii,p,delz) → Forcing
// tensors at the requested dtype, staged exactly like unpack_packed_state.
kdm6::Forcing unpack_packed_forcing(const double* packed, int im, int kme, int jme,
                                    c10::ScalarType dtype) {
    const int64_t N = static_cast<int64_t>(im) * kme * jme;
    auto opts = torch::TensorOptions().dtype(torch::kFloat64);
    auto one = [&](int f) {
        auto view3d = torch::from_blob(
            const_cast<double*>(packed) + static_cast<int64_t>(f) * N,
            {jme, kme, im}, opts)
                          .permute({2, 1, 0});
        return view3d.permute({0, 2, 1})
            .reshape({static_cast<int64_t>(im) * jme, kme})
            .clone().to(dtype);
    };
    kdm6::Forcing fc;
    fc.rho = one(0); fc.pii = one(1); fc.p = one(2); fc.delz = one(3);
    return fc;
}

// Value-only C boundary: export four forcing cotangents in the same native
// Fortran layout used by the inputs. This does not detach the live AD graph.
void pack_packed_forcing(const kdm6::Forcing& forcing, double* packed,
                         int im, int kme, int jme) {
    const int64_t n = static_cast<int64_t>(im) * kme * jme;
    const auto fields = forcing.fields();
    for (size_t f = 0; f < fields.size(); ++f) {
        auto t = fields[f]->detach().to(torch::kFloat64);
        TORCH_CHECK(t.numel() == n, "packed forcing field ", f, " numel mismatch");
        auto ordered = t.reshape({im, jme, kme}).permute({0, 2, 1})
                           .permute({2, 1, 0}).contiguous();
        std::memcpy(packed + static_cast<int64_t>(f) * n,
                    ordered.data_ptr<double>(), sizeof(double) * n);
    }
}

}  // namespace

// NOTE: diag_rhog/RHOPO3D is deliberately NOT part of the adjoint packed ABI.
// rhog is a FORWARD-only diagnostic (graupel density for radar reflectivity), not
// a prognostic state variable and not an adjoint quantity — 4D-Var never needs its
// gradient. It is exposed solely on the forward operational path (kdm6_step_c's
// rhog_out). state_out_packed here carries only the prognostic state.
static int kdm6_step_ad_variant_impl(
    const double* state_in_packed,
    const double* forcing_packed,
    int im, int kme, int jme, double dt,
    int value_only,
    double* state_out_packed,
    kdm6_handle_t** handle,
    const float* xland,
    double ncmin_land,
    double ncmin_sea,
    uint32_t physics_variant,
    int64_t dry_number,
    bool state_forcing_ad = false) {
    if (handle) *handle = nullptr;   // NULL output handle on every error path (see kdm6_step_c)
    if (im <= 0 || kme <= 0 || jme <= 0 ||
        !kdm6::fortran_packed_shape_fits(im, kme, jme, sizeof(double),
                                         /*field_count=*/12))
        return KDM6_ERR_INVALID_DIM;
    if (value_only != 0 && value_only != 1) return KDM6_ERR_INVALID_ARG;  // 0/1 flag only
    if (any_null({state_in_packed, forcing_packed, state_out_packed,
                  static_cast<const void*>(handle)})) {
        return KDM6_ERR_NULL_POINTER;
    }
    // The fp64 DA entry still uses the runtime's f32 dtcld timestep for the
    // Fortran-compatible subcycle schedule, but ncmin itself is staged in f64;
    // keep the finite/non-negative domain without imposing the operational
    // f32 upper bound on this separate DA path.
    if (invalid_operational_dt(dt) || invalid_ncmin(ncmin_land) || invalid_ncmin(ncmin_sea))
        return KDM6_ERR_INVALID_ARG;
    if (physics_variant != (uint32_t)KDM6_PHYSICS_LEGACY &&
        physics_variant != (uint32_t)KDM6_PHYSICS_CONSERVATIVE_INTERFACE &&
        physics_variant != (uint32_t)KDM6_PHYSICS_CONSERVATIVE_NORMALIZED)
        return KDM6_ERR_INVALID_ARG;
    if (dry_number < 0 || dry_number > 1) return KDM6_ERR_INVALID_ARG;
    kdm6::PhysicsOptions physics;
    physics.variant = static_cast<kdm6::PhysicsVariant>(physics_variant);
    // Same FP-env insulation as the operational kdm6_step_c: this fp64 DA entry also
    // calls into libtorch/BLAS, which could perturb FTZ/rounding and leak into host
    // dynamics when a DA workflow interleaves with the Fortran/WRF integration.
    FpEnvGuard kdm6_fpenv_guard;
    // Fail-closed thread fence (PR1-A) — same contract as kdm6_step_c: handle is
    // already NULL and the packed output buffer is untouched at this point.
    if (!ensure_libtorch_singlethread()) return KDM6_ERR_THREAD_CONFIG;
    try {
        // fp64 DA forward (design §0.1.A): same physics, float64 graph.
        auto state_in = unpack_packed_state(state_in_packed, im, kme, jme,
                                            c10::ScalarType::Double);
        if (value_only == 0) {
            auto sp = state_in.fields();
            for (auto* p : sp) p->requires_grad_(true);
        }
        auto forcing = unpack_packed_forcing(forcing_packed, im, kme, jme,
                                             c10::ScalarType::Double);
        if (state_forcing_ad && value_only == 0) {
            for (auto* field : forcing.fields()) field->requires_grad_(true);
        }
        auto params = kdm6::make_parameters(0);

        c10::optional<torch::Tensor> xland_t = c10::nullopt;
        if (xland != nullptr) {
            auto xopts = torch::TensorOptions().dtype(torch::kFloat32);
            auto view2d = torch::from_blob(const_cast<float*>(xland),
                                           {jme, im}, xopts)
                              .permute({1, 0})
                              .contiguous();
            const int64_t ncol = static_cast<int64_t>(im) *
                                 static_cast<int64_t>(jme);
            xland_t = view2d.reshape({ncol});
        }

        auto result = kdm6::kdm6_step(state_in, forcing, params, dt,
                                      value_only != 0, xland_t,
                                      ncmin_land, ncmin_sea, physics,
                                      dry_number == 1);
        pack_packed_state(result.state_out, state_out_packed, im, kme, jme);

        if (value_only != 0) {
            *handle = nullptr;
        } else {
            auto* h = new kdm6_handle_t{};
            h->impl = std::move(result.handle);
            h->im = im; h->kme = kme; h->jme = jme;
            h->dtype = c10::ScalarType::Double;   // fp64 DA graph
            h->state_forcing_ad = state_forcing_ad;
            *handle = h;
        }
        return KDM6_OK;
    } catch (const c10::NotImplementedError&) {
        return KDM6_ERR_NOT_IMPLEMENTED;
    } catch (const std::exception& e) {
        std::fprintf(stderr, "kdm6_step_ad_variant_c: %s\n", e.what());
        return KDM6_ERR_INTERNAL;
    } catch (...) {
        return KDM6_ERR_INTERNAL;
    }
}

extern "C" int kdm6_step_ad_variant_c(
    const double* state_in_packed, const double* forcing_packed,
    int im, int kme, int jme, double dt, int value_only,
    double* state_out_packed, kdm6_handle_t** handle,
    const float* xland, double ncmin_land, double ncmin_sea,
    uint32_t physics_variant) {
    return kdm6_step_ad_variant_impl(
        state_in_packed, forcing_packed, im, kme, jme, dt, value_only,
        state_out_packed, handle, xland, ncmin_land, ncmin_sea,
        physics_variant, /*dry_number=*/0);
}

extern "C" int kdm6_step_ad_number_c(
    const double* state_in_packed, const double* forcing_packed,
    int im, int kme, int jme, double dt, int value_only,
    double* state_out_packed, kdm6_handle_t** handle,
    const float* xland, double ncmin_land, double ncmin_sea,
    uint32_t physics_variant, int64_t dry_number) {
    return kdm6_step_ad_variant_impl(
        state_in_packed, forcing_packed, im, kme, jme, dt, value_only,
        state_out_packed, handle, xland, ncmin_land, ncmin_sea,
        physics_variant, dry_number);
}

extern "C" int kdm6_step_ad_c(
    const double* state_in_packed,
    const double* forcing_packed,
    int im, int kme, int jme, double dt,
    int value_only,
    double* state_out_packed,
    kdm6_handle_t** handle,
    const float* xland,
    double ncmin_land,
    double ncmin_sea) {
    return kdm6_step_ad_variant_c(
        state_in_packed, forcing_packed, im, kme, jme, dt, value_only,
        state_out_packed, handle, xland, ncmin_land, ncmin_sea,
        (uint32_t)KDM6_PHYSICS_LEGACY);
}

extern "C" int kdm6_step_ad_state_forcing_c(
    const double* state_in_packed, const double* forcing_packed,
    int im, int kme, int jme, double dt, int value_only,
    double* state_out_packed, kdm6_handle_t** handle,
    const float* xland, double ncmin_land, double ncmin_sea,
    uint32_t physics_variant, int64_t dry_number) {
    return kdm6_step_ad_variant_impl(
        state_in_packed, forcing_packed, im, kme, jme, dt, value_only,
        state_out_packed, handle, xland, ncmin_land, ncmin_sea,
        physics_variant, dry_number, true);
}

extern "C" int kdm6_handle_state_forcing_vjp_c(
    kdm6_handle_t* h, const double* u_packed,
    double* state_grad_packed, double* forcing_grad_packed) {
    if (!h || !h->impl || !u_packed || !state_grad_packed || !forcing_grad_packed)
        return KDM6_ERR_NULL_POINTER;
    if (h->impl->is_closed()) return KDM6_ERR_HANDLE_CLOSED;
    if (h->impl->is_value_only()) return KDM6_ERR_VALUE_ONLY;
    if (!h->state_forcing_ad) return KDM6_ERR_INVALID_ARG;
    if (h->im <= 0 || h->kme <= 0 || h->jme <= 0) return KDM6_ERR_INVALID_DIM;
    FpEnvGuard kdm6_fpenv_guard;
    if (!ensure_libtorch_singlethread()) return KDM6_ERR_THREAD_CONFIG;
    try {
        auto u = unpack_packed_state(u_packed, h->im, h->kme, h->jme, h->dtype);
        kdm6::GraphOptions opts;
        opts.retain_graph = true;
        auto grad = h->impl->vjp_state_forcing(u, opts);
        pack_packed_state(grad.state, state_grad_packed, h->im, h->kme, h->jme);
        pack_packed_forcing(grad.forcing, forcing_grad_packed, h->im, h->kme, h->jme);
        return KDM6_OK;
    } catch (const c10::NotImplementedError&) {
        return KDM6_ERR_NOT_IMPLEMENTED;
    } catch (const std::exception& e) {
        std::fprintf(stderr, "kdm6_handle_state_forcing_vjp_c: %s\n", e.what());
        return KDM6_ERR_INTERNAL;
    } catch (...) { return KDM6_ERR_INTERNAL; }
}

extern "C" int kdm6_handle_state_forcing_jvp_c(
    kdm6_handle_t* h, const double* state_direction_packed,
    const double* forcing_direction_packed, double* tangent_out_packed) {
    if (!h || !h->impl || !state_direction_packed || !forcing_direction_packed || !tangent_out_packed)
        return KDM6_ERR_NULL_POINTER;
    if (h->impl->is_closed()) return KDM6_ERR_HANDLE_CLOSED;
    if (h->impl->is_value_only()) return KDM6_ERR_VALUE_ONLY;
    if (!h->state_forcing_ad) return KDM6_ERR_INVALID_ARG;
    if (h->im <= 0 || h->kme <= 0 || h->jme <= 0) return KDM6_ERR_INVALID_DIM;
    FpEnvGuard kdm6_fpenv_guard;
    if (!ensure_libtorch_singlethread()) return KDM6_ERR_THREAD_CONFIG;
    try {
        auto vs = unpack_packed_state(state_direction_packed, h->im, h->kme, h->jme, h->dtype);
        auto vf = unpack_packed_forcing(forcing_direction_packed, h->im, h->kme, h->jme, h->dtype);
        kdm6::GraphOptions opts;
        opts.retain_graph = true;
        auto tangent = h->impl->jvp_state_forcing(vs, vf, opts);
        pack_packed_state(tangent, tangent_out_packed, h->im, h->kme, h->jme);
        return KDM6_OK;
    } catch (const c10::NotImplementedError&) {
        return KDM6_ERR_NOT_IMPLEMENTED;
    } catch (const std::exception& e) {
        std::fprintf(stderr, "kdm6_handle_state_forcing_jvp_c: %s\n", e.what());
        return KDM6_ERR_INTERNAL;
    } catch (...) { return KDM6_ERR_INTERNAL; }
}

extern "C" int kdm6_handle_vjp_c(kdm6_handle_t* h,
                                  const double* u_packed,
                                  double* grad_out_packed) {
    if (!h || !h->impl) return KDM6_ERR_NULL_POINTER;
    if (!u_packed || !grad_out_packed) return KDM6_ERR_NULL_POINTER;
    if (h->impl->is_closed()) return KDM6_ERR_HANDLE_CLOSED;
    if (h->impl->is_value_only()) return KDM6_ERR_VALUE_ONLY;
    if (h->im <= 0 || h->kme <= 0 || h->jme <= 0) return KDM6_ERR_INVALID_DIM;

    FpEnvGuard kdm6_fpenv_guard;  // torch autograd (backward) may touch FP env — insulate host
    // VJP/JVP are ABI entries too: enforce the same fail-closed single-thread
    // contract as every forward entry before unpacking tensors or writing the
    // caller's gradient buffer.
    if (!ensure_libtorch_singlethread()) return KDM6_ERR_THREAD_CONFIG;
    try {
        auto u = unpack_packed_state(u_packed, h->im, h->kme, h->jme, h->dtype);
        // Repeat-callable by design at the ABI (a DA driver may apply several
        // observation adjoints to one step) — retain the forward graph.
        kdm6::GraphOptions opts;
        opts.retain_graph = true;
        auto grad = h->impl->vjp(u, opts);
        pack_packed_state(grad, grad_out_packed, h->im, h->kme, h->jme);
        return KDM6_OK;
    } catch (const c10::NotImplementedError&) {
        return KDM6_ERR_NOT_IMPLEMENTED;
    } catch (const std::exception& e) {
        std::fprintf(stderr, "kdm6_handle_vjp_c: %s\n", e.what());
        return KDM6_ERR_INTERNAL;
    } catch (...) {
        return KDM6_ERR_INTERNAL;
    }
}

extern "C" int kdm6_handle_jvp_c(kdm6_handle_t* h,
                                  const double* v_packed,
                                  double* tangent_out_packed) {
    if (!h || !h->impl) return KDM6_ERR_NULL_POINTER;
    if (!v_packed || !tangent_out_packed) return KDM6_ERR_NULL_POINTER;
    if (h->impl->is_closed()) return KDM6_ERR_HANDLE_CLOSED;
    if (h->impl->is_value_only()) return KDM6_ERR_VALUE_ONLY;
    if (h->im <= 0 || h->kme <= 0 || h->jme <= 0) return KDM6_ERR_INVALID_DIM;

    FpEnvGuard kdm6_fpenv_guard;  // Pearlmutter double-VJP (autograd) may touch FP env — insulate host
    if (!ensure_libtorch_singlethread()) return KDM6_ERR_THREAD_CONFIG;
    try {
        auto v = unpack_packed_state(v_packed, h->im, h->kme, h->jme, h->dtype);
        // Pearlmutter double-VJP under the hood (Handle::jvp); the forward
        // graph is retained, so jvp/vjp may be interleaved on one handle.
        auto tangent = h->impl->jvp(v);
        pack_packed_state(tangent, tangent_out_packed, h->im, h->kme, h->jme);
        return KDM6_OK;
    } catch (const c10::NotImplementedError&) {
        return KDM6_ERR_NOT_IMPLEMENTED;
    } catch (const std::exception& e) {
        std::fprintf(stderr, "kdm6_handle_jvp_c: %s\n", e.what());
        return KDM6_ERR_INTERNAL;
    } catch (...) {
        return KDM6_ERR_INTERNAL;
    }
}

extern "C" int kdm6_handle_close_c(kdm6_handle_t* h) {
    if (!h) return KDM6_OK;
    if (h->impl) h->impl->close();
    delete h;
    return KDM6_OK;
}

// Pointer-nulling close (recommended): frees *hp and resets it to NULL so the
// caller's handle can never dangle. Idempotent on NULL / *NULL.
extern "C" int kdm6_handle_closep_c(kdm6_handle_t** hp) {
    if (!hp || !*hp) return KDM6_OK;
    if ((*hp)->impl) (*hp)->impl->close();
    delete *hp;
    *hp = nullptr;
    return KDM6_OK;
}
