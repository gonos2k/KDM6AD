#!/usr/bin/env python3
"""Generation-pinned GCS range capture for one VIIRS row/column; never fetch whole objects."""
from __future__ import annotations
import hashlib, json, urllib.parse, urllib.request
from pathlib import Path
import h5py
import numpy as np

ROOT=Path(__file__).resolve().parent
BUCKET='gcp-noaa-nesdis-n20'
ROW=205
COL=27
MAX_BYTES=100_000_000
BLOCK=262_144
PRODUCTS={
 'phase':{
  'key':'VIIRS-JRR-CloudPhase/2025/07/19/JRR-CloudPhase_v3r2_j01_s202507190555475_e202507190557102_c202507190621171.nc',
  'fields':['Latitude','Longitude','CloudPhase','CloudPhaseFlag','CloudType','CloudTypePacked','StartRow','StartColumn','granule_level_quality_flag']},
 'height':{
  'key':'VIIRS-JRR-CloudHeight/2025/07/19/JRR-CloudHeight_v3r2_j01_s202507190555475_e202507190557102_c202507190621171.nc',
  'fields':['Latitude','Longitude','Latitude_Pc','Longitude_Pc','CldTopHght','CldTopTemp','CldTopPres','CldTopPresLow','CldTopTempLow','CldTopHghtLow','CldHgtFlag','CloudHgtQF','CldOptDpth','StartRow','StartColumn','granule_level_quality_flag']},
 'dcomp':{
  'key':'VIIRS-JRR-CloudDCOMP/2025/07/19/JRR-CloudDCOMP_v3r2_j01_s202507190555475_e202507190557102_c202507190627286.nc',
  'fields':['Latitude','Longitude','CloudMicroVisOD','CloudMicroEffRad','CloudMicroLWP','CloudMicroIWP','VisOD_uncertainty','EffRad_uncertainty','EQualityFlag','StartRow','StartColumn','granule_level_quality_flag']},
}


def plain(x):
    if isinstance(x, np.ndarray): return x.tolist()
    if isinstance(x, np.generic): return plain(x.item())
    if isinstance(x, bytes): return x.decode('utf-8','replace')
    if isinstance(x, dict): return {str(k):plain(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)): return [plain(v) for v in x]
    return x

class PinnedRangeFile:
    def __init__(self, url, generation, size, raw_dir, product):
        self.base_url=url; self.generation=str(generation); self.size=int(size)
        self.block=BLOCK; self.pos=0; self.cache={}; self.bytes=0; self.calls=0; self.records=[]
        self.raw_dir=raw_dir/product; self.raw_dir.mkdir(parents=True,exist_ok=True)
    def seek(self,off,whence=0):
        if whence==0:p=off
        elif whence==1:p=self.pos+off
        elif whence==2:p=self.size+off
        else:raise ValueError('invalid whence')
        self.pos=max(0,min(self.size,p));return self.pos
    def tell(self):return self.pos
    def read(self,n=-1):
        if n is None or n<0:n=self.size-self.pos
        end=min(self.size,self.pos+n);out=bytearray()
        while self.pos<end:
            bi=self.pos//self.block
            if bi not in self.cache:
                start=bi*self.block;stop=min(self.size,start+self.block)-1
                url=self.base_url+'&generation='+urllib.parse.quote(self.generation)
                req=urllib.request.Request(url,headers={'Range':f'bytes={start}-{stop}','User-Agent':'KDM6AD-generation-pinned-viirs-context/1.0'})
                with urllib.request.urlopen(req,timeout=60) as r:
                    body=r.read();cr=r.headers.get('Content-Range')
                    expected=f'bytes {start}-{stop}/{self.size}'
                    if r.status!=206 or cr!=expected or len(body)!=(stop-start+1):
                        raise RuntimeError(f'range mismatch: status={r.status} content-range={cr!r}, expected={expected!r}, bytes={len(body)}')
                sha=hashlib.sha256(body).hexdigest()
                fn=self.raw_dir/f'bytes_{start}_{stop}.bin';fn.write_bytes(body)
                self.cache[bi]=body;self.bytes+=len(body);self.calls+=1
                self.records.append({'start':start,'end':stop,'content_range':expected,'bytes':len(body),'sha256':sha,'raw_file':str(fn.relative_to(ROOT))})
                if self.bytes>MAX_BYTES:raise RuntimeError(f'byte bound exceeded: {self.bytes}')
            body=self.cache[bi];start=bi*self.block;offset=self.pos-start;take=min(end-self.pos,len(body)-offset)
            out.extend(body[offset:offset+take]);self.pos+=take
        return bytes(out)
    def flush(self):pass
    def readable(self):return True
    def seekable(self):return True
    def close(self):pass


def fetch_metadata(product,key):
    url=f'https://storage.googleapis.com/storage/v1/b/{BUCKET}/o/'+urllib.parse.quote(key,safe='')
    req=urllib.request.Request(url,headers={'User-Agent':'KDM6AD-GCS-object-metadata/1.0'})
    with urllib.request.urlopen(req,timeout=30) as r: body=r.read()
    digest=hashlib.sha256(body).hexdigest()
    path=ROOT/'object_metadata'/f'{product}.json';path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(body)
    m=json.loads(body)
    for k in ('name','generation','metageneration','size','md5Hash','crc32c','updated','timeCreated','contentType','storageClass'):
        if k not in m:raise ValueError(f'{product} object metadata missing {k}')
    return m,{'url':url,'response_sha256':digest,'response_bytes':len(body),'raw_file':str(path.relative_to(ROOT))}


def attr_subset(obj):
    keep=('long_name','units','_FillValue','valid_range','scale_factor','add_offset','flag_values','flag_masks','flag_meanings','coordinates','description')
    return {k:plain(obj.attrs[k]) for k in keep if k in obj.attrs}


def main():
    raw_dir=ROOT/'raw_ranges'; results={}; total=0
    for product, spec in PRODUCTS.items():
        meta,meta_receipt=fetch_metadata(product,spec['key'])
        # Pinned to the immutable Cloud Storage object generation from its metadata response.
        url=f'https://storage.googleapis.com/download/storage/v1/b/{BUCKET}/o/'+urllib.parse.quote(spec['key'],safe='')+'?alt=media'
        f=PinnedRangeFile(url,meta['generation'],meta['size'],raw_dir,product)
        with h5py.File(f,'r') as h:
            globals_keep=('title','history','history_package','time_coverage_start','time_coverage_end','date_created','satellite_name','instrument','resolution','day_night_data_flag','geospatial_bounds','source','sensor_band_identifier','sensor_band_central_radiation_wavelength','start_orbit_number','end_orbit_number')
            globals_out={k:plain(h.attrs[k]) for k in globals_keep if k in h.attrs}
            fields={}
            for name in spec['fields']:
                if name not in h:continue
                d=h[name]
                entry={'shape':list(d.shape),'dtype':str(d.dtype),'chunks':list(d.chunks) if d.chunks else None,'compression':d.compression,'attributes':attr_subset(d)}
                if d.shape in [(),(1,)]:
                    entry['raw_value']=plain(d[()] if d.shape==() else d[0])
                elif d.ndim==2:
                    entry['raw_value']=plain(d[ROW,COL])
                elif d.ndim==3:
                    entry['raw_value']=plain(d[ROW,COL,:])
                else:
                    entry['sample_not_read']='shape not sampled by target index'
                fields[name]=entry
        total+=f.bytes
        results[product]={
            'gcs_object':{k:meta[k] for k in ('name','generation','metageneration','size','md5Hash','crc32c','updated','timeCreated','contentType','storageClass')},
            'object_metadata_response':meta_receipt,'generation_pinned_media_url':url+'&generation='+urllib.parse.quote(str(meta['generation']),'') ,
            'global_attributes':globals_out,'target_index_zero_based':[ROW,COL],
            'fields':fields,'range_transfer':{'block_bytes':BLOCK,'unique_response_bytes':f.bytes,'range_call_count':f.calls,'ranges':f.records,
                'full_original_downloaded':False,'dataset_read_method':'h5py raw access; no netCDF masks/scales applied.'}}
    if total>MAX_BYTES:raise RuntimeError(f'total range transfer {total} exceeds limit')
    # Compare actual geolocation at the same row/column across each product.
    coords={k:{'latitude':v['fields'].get('Latitude',{}).get('raw_value'),'longitude':v['fields'].get('Longitude',{}).get('raw_value')} for k,v in results.items()}
    result={'schema':'jrr_viirs_context_target_sample_v1','capture_utc':__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat(),
        'official_source':'NOAA NODD Google Cloud JPSS NOAA-20 bucket',
        'bucket':BUCKET,'target_reference':{'coordinates_deg':[35.415638,122.143387],'reported_cloudphase_index_zero_based':[ROW,COL]},
        'products':results,'target_geolocation_by_product':coords,'total_unique_range_bytes_downloaded':total,'maximum_range_bytes':MAX_BYTES,
        'full_granule_files_downloaded':False,'pixel_values_sampled':True,
        'QA_policy':'All values are raw HDF5 dataset values; no _FillValue masking, valid_range filtering, bit decoding, or scaling was applied. Preserve out-of-range values exactly.',
        'limitations':['The three products are derived outputs from the same NOAA-20 VIIRS granule, not independent observations.','Pixel time is the file granule interval, not an independently resolved scan-time for this target.','The coordinate/index match is recorded from product geolocation arrays; it does not establish direct agreement with an independently geolocated retrieval or model state.']}
    path=ROOT/'target_sample_result.json';path.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'result':str(path),'total_range_bytes':total,'per_product':{k:v['range_transfer']['unique_response_bytes'] for k,v in results.items()},'coords':coords,
        'phase':results['phase']['fields'].get('CloudPhase',{}).get('raw_value'),'phase_flag':results['phase']['fields'].get('CloudPhaseFlag',{}).get('raw_value'),
        'height':results['height']['fields'].get('CldTopHght',{}).get('raw_value'),'dcomp':results['dcomp']['fields'].get('CloudMicroVisOD',{}).get('raw_value')},indent=2))

if __name__=='__main__':main()
