# NOAA-20 VIIRS target-pixel context — 2025-07-19

This bounded sample uses official NOAA JPSS data in the public Google Cloud bucket `gcp-noaa-nesdis-n20`. The NOAA JPSS Data Access page links Google Cloud access; the NODD registry lists the NOAA-20 cloud dataset. The range reader pins each GCS object generation, checks HTTP `Content-Range`, and stores SHA-256 hashes for each retrieved byte range. It did not download any complete granule. The sample result is [target_sample_result.json](target_sample_result.json); captured range payloads and GCS metadata are next to it.

The three files share the exact granule start/end token `s202507190555475_e202507190557102` and identical global coverage `2025-07-19T05:55:47Z`–`05:57:10Z`. They are versioned delivery-package `v3r2` outputs from one NOAA-20 VIIRS overpass, not independent measurements:

| Product | Product algorithm reported in file | Important sampled variables |
| --- | --- | --- |
| JRR-CloudPhase | Enterprise Cloud Phase and Type v2.2.0 | `CloudPhase`, `CloudPhaseFlag`, `CloudType`, `CloudTypePacked` |
| JRR-CloudHeight | Enterprise Cloud Height v2.4.1 | `CldTopHght`, `CldTopTemp`, `CldTopPres`, low-layer outputs, `CloudHgtQF`, `CldHgtFlag`, `CldOptDpth` |
| JRR-CloudDCOMP | Enterprise daytime Cloud Optical and Microphysical Properties v2.1.1 | `CloudMicroVisOD`, `CloudMicroEffRad`, `CloudMicroLWP`, `CloudMicroIWP`, `EQualityFlag`, uncertainty fields |

At zero-based array row 205, column 27, all three files’ `Latitude`/`Longitude` arrays return 35.41563797° N, 122.14338684° E, agreeing with the supplied target coordinate (35.415638° N, 122.143387° E) to float32 precision. The CloudHeight file additionally gives parallax-corrected coordinates 35.41522598° N, 122.12656403° E. The algorithm output at that point is 587.73694 m cloud-top height, 296.57068 K cloud-top temperature, 940.98523 hPa cloud-top pressure, and ACHA infrared optical depth 1.1430864. DCOMP separately returns optical depth 2.6809735, effective radius 113.5573 µm, LWP 169.1356 g/m², and IWP 169.1357 g/m². These are retrieval outputs from the same sensor/scene; they are not an independent truth pair.

The raw quality fields are preserved without mask, scale, or bit decoding. At this target, CloudPhase is raw code `1`, `CloudPhaseFlag` is `[0]`, `CloudType` is `2`, and `CloudTypePacked` is `[3, -128, 8, 0, 0, 0]`. CloudHeight gives `CloudHgtQF=0`, `CldHgtFlag=[3,1,1,1,1]`, and granule-level flag 0. DCOMP gives `EQualityFlag=17`, although that dataset’s own `valid_range` attribute is `[0,6]`; the raw value is retained and not interpreted as a valid category. Fill values are present for lower-layer cloud pressure/temperature. Do not treat the field’s declared range as a decoder or silently mask this stored code.

The captured byte ranges total **8,235,094 bytes** across all three files, below the 100 MB bound. `gcs_object` in the result pins generation, metageneration, object size, MD5, CRC32C, update/create times, and content type. No full-object SHA-256 is asserted because no full granule was downloaded; the SHA-256 values apply to the exact retrieved ranges. The field reads used raw h5py/HDF5 access, so netCDF auto-masking/scaling was not applied.

No external model/reanalysis/profile data were accessed. No model or RTTOV run was performed. The output fields are same-family NOAA retrievals and ancillary-input-derived products; they do not independently validate the KDM state.

Official sources:

- [NOAA STAR JPSS data access](https://www.star.nesdis.noaa.gov/jpss/DataAccess.php)
- [NOAA NODD JPSS registry](https://registry.opendata.aws/noaa-jpss/)
- [NOAA STAR cloud products and product descriptions](https://www.star.nesdis.noaa.gov/jpss/clouds.php)
- [Enterprise Cloud Height ATBD v3.4](https://www.star.nesdis.noaa.gov/jpss/documents/ATBD/ATBD_EPS_Cloud_ACHA_v3.4.pdf)
- [Enterprise DCOMP ATBD v1.2](https://www.star.nesdis.noaa.gov/jpss/documents/ATBD/ATBD_EPS_Cloud_DCOMP_v1.2.pdf)
- [JPSS EUM v1.2](https://www.ospo.noaa.gov/Products/land/docs/JRRPS_EUM_1.2.pdf)
