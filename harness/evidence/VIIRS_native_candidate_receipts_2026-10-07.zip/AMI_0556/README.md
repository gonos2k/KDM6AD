# NOAA GK-2A LA 05:56 slot — metadata receipt

The public S3 listing returned all nine expected LA AMI 8–16 channel keys for `202507190556`, totaling 4,415,402 bytes. This is below the 6 MB bound. The files were retrieved into this private case folder and SHA-256 pinned; no pixel array was read or decoded. The current dedicated LA reader source accepts the same nine channels and declares the 500×500 LA020GE geometry, but the reader was not executed on this slot.

IR105 header metadata reports a 500×500 image, LA/GEOS, 2 km spatial resolution, `scene_acquisition_time=20250719_055656` (OBT), and `mission_reference_time=20250719_055000` (planned UTC). The numeric `observation_start_time/end_time` and `time_synchro_utc/obt` are preserved raw. No UTC conversion is made.

Header scene anchors convert from radians to upper-left (44.1749 N, 119.9145 E), center (37.1655 N, 126.7083 E), and lower-right (31.1147 N, 132.2056 E). The target western box 32–40 N, 120–123 E lies within that coarse rectangular envelope, but this does not prove any pixel overlap. Pixel geolocation and phase remain uninspected. The 05:56 filename slot is temporally adjacent to the coordinator-provided NOAA-20 VIIRS interval 05:54:21–05:58:36 UTC. This interval was not independently rechecked in this capture, and LA time is OBT and not verified as UTC; no same-case claim is made.

The full file inventory, URLs, object lengths/ETags, hashes, header attributes, and source-listing hash are in [slot_receipt.json](slot_receipt.json). The original files are stored beside it.
