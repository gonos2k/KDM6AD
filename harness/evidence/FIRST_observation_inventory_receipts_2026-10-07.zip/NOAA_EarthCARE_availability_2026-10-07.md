# NOAA GK-2A / EarthCARE metadata availability — 2026-10-07

This packet records official catalogue and object metadata for two EarthCARE passes crossing an eastern-Korea search box near 2025 summer GK-2A local-area slots. It is an acquisition shortlist, not a selected science case. No EarthCARE product bytes, GK-2A image pixels, product phase labels, or QA values were read. One 531,907-byte NOAA LA IR105 product was fetched only to inspect its NetCDF header, as requested. No model or reanalysis data were acquired and no host run was performed.

The retained canonical 5-km input is still the sole model dataset: 2025-07-19 00:00:00, 00:00:20, and 00:00:40 UTC. The EarthCARE candidates below occur several hours later. They do not have a matched native model frame, and this packet makes no model-match claim.

## NOAA GK-2A: public LA listings near EarthCARE passes

Unsigned S3 ListObjectsV2 metadata returns an IR105 LA object at each two-minute slot around the two candidate passes. The 2025-07-19 05:34 LA object is the only science file fetched; its byte count and hash match the S3 listing. An unsigned HEAD returned 200. No pixel values were read.

| Nominal slot (UTC) | Object suffix | ETag | Size | Use |
|---|---|---|---:|---|
| 2025-07-18 16:52 | `ir105_la020ge_202507181652.nc` | `d466d1cac5c296bf2a6fe3879adc8809` | 507,725 B | listing only |
| 2025-07-19 05:32 | `ir105_la020ge_202507190532.nc` | `703423d8060d82d4720c3e68831e0232` | 519,150 B | listing only |
| 2025-07-19 05:34 | `ir105_la020ge_202507190534.nc` | `cd3b207af11bb3bec024ce399348d9bd` | 531,907 B | header only; SHA-256 `49ed9109637c68465c3d19938b0c794092dcb50b92afb7105ce0d687803789ce` |
| 2025-07-19 05:36 | `ir105_la020ge_202507190536.nc` | `bf786e68d5794bb0407f87430963c540` | 532,054 B | listing only |

The NOAA 05:34 header identifies an AMI IR105 `LA` file from NMSC, `GK2_INRSM_V1.3`, 500×500 pixels, 2 km resolution, GEOS projection, and KMA calibration table v3.0. It stores `scene_acquisition_time=20250719_053442`, `mission_reference_time=20250719_053000`, and `file_generation_time=20250719_053600`. The numeric global attributes are `observation_start_time=806175282.4338461`, `observation_end_time=806175343.6724635`, `time_synchro_utc=806175282.4398186`, and `time_synchro_obt=806175282.4338461`. The inspected header contains no units/epoch attribute for those numeric fields; the values are preserved verbatim without conversion. The image variable advertises 16 total bits, 13 valid bits, two DQF bits, and meanings `0 good`, `1 conditionally usable`, `2 out of scan area`, `3 error`; the product header reports zero error pixels. Those are variable-level metadata, not a statement about any individual pixel.

The header has scene-level navigation fields including first/center/last spacecraft positions and solar/view angle fields, but this inventory did not map a pixel or compare it to an EarthCARE sample. The 05:34 nominal slot and stored scene-acquisition time fall near the start of orbit 06477D's metadata interval; this is only a candidate temporal overlap. Exact per-pixel collocation remains unknown.

The NOAA exact-prefix listing for the named 05:34 `ELA` IR105 parent returned `KeyCount=0` and was not truncated. The exact 00:00 ELA and FD/LA listing receipts are also retained. NOAA LA is a separate public product arm; it does not establish or replace the local KMA `KO020lc`/named ELA source lineage.

## EarthCARE catalogue results

Anonymous ESA MAAP STAC metadata search used the broad Korean East-region box `[126.5,34.0,130.0,39.5]` for `2025-07-18T00:00:00Z/2025-07-20T23:59:59Z`. It returned 10 validated L1 items, 48 ESA validated L2 items, and 4 JAXA validated L2 items. A narrower box around the retained C5 site `[122.8,38.0,124.2,39.4]` returned zero L1/L2 items in all three queried collections. The catalogued candidates are therefore on the eastern-Korea search area, not the existing western-sea C5 point.

Two pass records are useful for an observation-only shortlist:

| Orbit | Acquisition interval UTC | Relevant metadata-listed products |
|---|---|---|
| `06469B` | 2025-07-18 16:51:45–17:03:32 | JAXA `MSI_CLP_2A` BA: `ECA_JXBA_MSI_CLP_2A_20250718T165145Z_20250718T191458Z_06469B`; reprocessed CA: `ECA_JXCA_MSI_CLP_2A_20250718T165145Z_20260512T032452Z_06469B`; ESA `MSI_COP_2A`, `MSI_CM__2A`, `CPR_CLD_2A`, `AC__TC__2B`, plus L1 MSI/CPR products. |
| `06477D` | 2025-07-19 05:34:57–05:46:44 | JAXA `MSI_CLP_2A` BA: `ECA_JXBA_MSI_CLP_2A_20250719T053457Z_20250719T080243Z_06477D`; reprocessed CA: `ECA_JXCA_MSI_CLP_2A_20250719T053457Z_20260512T042641Z_06477D`; ESA `MSI_COP_2A`, `MSI_CM__2A`, `AC__TC__2B`, plus L1 MSI/CPR products. |

The exact ESA product IDs, versions, processing timestamps, bounding-box result counts, and the full filtered response JSONs are in the companion JSON and raw query responses. JAXA’s official product notes describe MSI L2 cloud flags that include cloud-phase information, while ESA’s catalog provides synergistic target-classification products. This establishes candidate products only: **phase is unknown** until the science pixels and their quality flags are read and checked. The orbit-data catalog query returned zero for the selected time/bbox; no orbit auxiliary file was fetched.

## Access and limits

NOAA’s S3 listing and the selected LA IR105 object were reachable anonymously. This is distinct from the missing ELA key and from the local KO files.

ESA MAAP returned STAC metadata anonymously, but the selected product assets are marked `auth:refs=oidc`; an EO Sign In account/token is required for asset access. The validated L1/L2 collections are separate from commissioning-team and Cal/Val collections, which have extra restrictions. The JAXA MAAP items also expose OIDC-protected assets. JAXA’s G-Portal provides free standard products, but downloading requires its current account/sign-in process; follow the post-2026-10-01 current G-Portal CSW/SFTP guidance rather than relying on stale endpoints. No JAXA or ESA product file was downloaded.

## Preserved evidence

`NOAA_EarthCARE_availability_2026-10-07.json` records the selected object/granule identifiers, exact timestamps and raw time fields, authorization observations, query parameters, and SHA-256 receipts for each small NOAA XML / ESA STAC JSON response. The downloaded NOAA NetCDF is `noaa_la_ir105_202507190534.nc`; its hash is listed there. The remaining query response bodies are also saved in this ignored directory. No phase labels, per-pixel spatial/temporal match, or new 5-km date match are claimed.

Official starting points: [NOAA GK-2A Open Data registry](https://registry.opendata.aws/noaa-gk2a-pds/), [NMSC LA observation description](https://nmsc.kma.go.kr/homepage/html/special/specialIntro.do?lang=ko), [ESA MAAP EarthCARE data offer](https://portal.maap.eo.esa.int/earthcare/earthcare-data-offer/), [ESA MAAP STAC API](https://catalog.maap.eo.esa.int/doc/stac.html), [JAXA G-Portal](https://www.gportal.jaxa.jp/gpr/), and [JAXA EarthCARE product list](https://gportal.jaxa.jp/gpr/assets/mng_upload/EarthCARE/EarthCare_Product_List.pdf).
