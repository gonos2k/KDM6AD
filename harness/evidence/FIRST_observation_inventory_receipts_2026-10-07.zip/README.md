# NASA CMR cloud-granule metadata inventory

This is a small, unauthenticated metadata-only search of NASA's Common Metadata Repository for MODIS Collection 6.1 cloud Level-2 granules intersecting the approximate Korean-seas box `120,30,135,42` during 2025-04-01 through 2025-10-01. No granule science data were fetched and no science QA was read.

| Product / granule | CMR observation interval (UTC) | CMR granule size | Day/night | Direct metadata-listed data link |
|---|---|---:|---|---|
| `MYD06_L2.A2025091.0535.061.2025091220356.hdf` | 2025-04-01 05:35–05:40 | 99.53 MB | DAY | [LAADS object](https://data.laadsdaac.earthdatacloud.nasa.gov/prod-lads/MYD06_L2/MYD06_L2.A2025091.0535.061.2025091220356.hdf) |
| `MOD06_L2.A2025200.0045.061.2025205141805.hdf` | 2025-07-19 00:45–00:50 | 76.59 MB | DAY | [LAADS object](https://data.laadsdaac.earthdatacloud.nasa.gov/prod-lads/MOD06_L2/MOD06_L2.A2025200.0045.061.2025205141805.hdf) |
| `MOD06_L2.A2025263.0110.061.2025263203907.hdf` | 2025-09-20 01:10–01:15 | 117.66 MB | DAY | [LAADS object](https://data.laadsdaac.earthdatacloud.nasa.gov/prod-lads/MOD06_L2/MOD06_L2.A2025263.0110.061.2025263203907.hdf) |
| `MOD06_L2.A2025263.1215.061.2025264014149.hdf` | 2025-09-20 12:15–12:20 | 17.33 MB | NIGHT | [LAADS object](https://data.laadsdaac.earthdatacloud.nasa.gov/prod-lads/MOD06_L2/MOD06_L2.A2025263.1215.061.2025264014149.hdf) |

Unauthenticated HTTP HEAD probes of all four metadata-listed LAADS object URLs redirected to a CloudFront signed-head URL and returned HTTP 403, with no `WWW-Authenticate` header. This establishes only that unauthenticated HEAD was denied in this environment; it does not establish whether Earthdata Login, the method, or another access policy caused the denial. No credentials were supplied and no granule bytes were requested.

Each CMR footprint polygon is retained verbatim in `NASA_CMR_MODIS_cloud_granule_inventory_2026-10-07.json`; the polygon-level spatial test is only CMR intersection with the requested bounding box. It does not establish a specific pixel location or footprint correspondence.

The July 19 Terra swath starts 45 minutes after the retained native model's 00:00:00 initial frame and 44 minutes 20 seconds after its final 00:00:40 frame. These are candidate products, not time-matched observations; the granule's five-minute interval also is not the pixel's exact scan time. The metadata labels three candidates DAY and one NIGHT; cloud phase is unknown for all four until product science QA is read. Dates, day/night labels, and the product name do not classify a warm-liquid case.

The raw collection and one-granule CMR response bodies are in `raw/` and individually SHA-256-pinned in the JSON receipt. `capture_cmr_metadata.py` reruns only six small CMR metadata requests (two collection records and four selected granules; no data-object requests).
