#!/usr/bin/env python3
"""Fetch only selected NASA CMR metadata records; never fetch granule data."""
from __future__ import annotations

import hashlib
import json
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

OUT = Path(__file__).resolve().parent
BASE = "https://cmr.earthdata.nasa.gov/search"
BBOX = "120,30,135,42"
WINDOW = ("2025-04-01T00:00:00Z", "2025-10-01T00:00:00Z")
PRODUCTS = {
    "MOD06_L2": "C1443535037-LAADS",
    "MYD06_L2": "C1443536017-LAADS",
}
GRANULES = (
    ("MYD06_L2", "MYD06_L2.A2025091.0535.061.2025091220356.hdf"),
    ("MOD06_L2", "MOD06_L2.A2025200.0045.061.2025205141805.hdf"),
    ("MOD06_L2", "MOD06_L2.A2025263.0110.061.2025263203907.hdf"),
    ("MOD06_L2", "MOD06_L2.A2025263.1215.061.2025264014149.hdf"),
)


def fetch_json(name: str, endpoint: str, params: dict) -> tuple[dict, dict, str, str]:
    url = f"{BASE}/{endpoint}?{urllib.parse.urlencode(params)}"
    request = urllib.request.Request(
        url, headers={"Accept": "application/json",
                    "User-Agent": "KDM6AD-CMR-metadata-inventory/1.0"})
    with urllib.request.urlopen(request, timeout=45) as response:
        raw = response.read()
        headers = {key: response.headers.get(key) for key in
                   ("CMR-Hits", "CMR-Request-Id", "CMR-Took", "Content-Type")}
    path = OUT / "raw" / name
    path.write_bytes(raw)
    digest = hashlib.sha256(raw).hexdigest()
    return json.loads(raw), headers, url, digest


def main() -> None:
    receipt = {
        "source": "NASA Common Metadata Repository (CMR) public search API",
        "api_base": BASE,
        "authentication": "none; unauthenticated metadata API only",
        "granule_data_downloaded": False,
        "science_qa_read": False,
        "bbox_west_south_east_north_deg": [120, 30, 135, 42],
        "search_window_utc": list(WINDOW),
        "captured_utc": datetime.now(timezone.utc).isoformat(),
        "collections": [],
        "granules": [],
    }
    for short_name, concept_id in PRODUCTS.items():
        body, headers, url, digest = fetch_json(
            f"collection_{short_name}_v061.json", "collections.json",
            {"short_name": short_name, "version": "6.1", "page_size": 5})
        entries = body.get("feed", {}).get("entry", [])
        matched = [entry for entry in entries if entry.get("id") == concept_id]
        if len(matched) != 1:
            raise RuntimeError(f"expected exactly one {short_name} collection {concept_id}, got {len(matched)}")
        entry = matched[0]
        receipt["collections"].append({
            "short_name": short_name, "version": "6.1", "concept_id": concept_id,
            "title": entry.get("title"), "doi": entry.get("doi"),
            "time_start": entry.get("time_start"),
            "provider_id": entry.get("provider_id"),
            "query_url": url, "response_headers": headers,
            "raw_metadata": f"raw/collection_{short_name}_v061.json",
            "raw_metadata_sha256": digest,
        })

    for index, (short_name, producer_id) in enumerate(GRANULES, start=1):
        concept_id = PRODUCTS[short_name]
        body, headers, url, digest = fetch_json(
            f"granule_{index:02d}_{producer_id}.json", "granules.json",
            {"collection_concept_id": concept_id,
             "producer_granule_id": producer_id,
             "bounding_box": BBOX,
             "temporal": ",".join(WINDOW),
             "page_size": 5})
        entries = body.get("feed", {}).get("entry", [])
        if len(entries) != 1 or entries[0].get("producer_granule_id") != producer_id:
            raise RuntimeError(f"expected exact CMR granule {producer_id}; response count={len(entries)}")
        entry = entries[0]
        links = entry.get("links", [])
        data_links = [link.get("href") for link in links
                      if link.get("rel") == "http://esipfed.org/ns/fedsearch/1.1/data#"
                      and link.get("href") and "/prod-lads/" in link["href"]]
        metadata_dois = [link.get("href") for link in links
                         if link.get("rel") == "http://esipfed.org/ns/fedsearch/1.1/metadata#"]
        receipt["granules"].append({
            "product": short_name,
            "collection_concept_id": concept_id,
            "granule_concept_id": entry.get("id"),
            "producer_granule_id": producer_id,
            "provider_id": entry.get("provider_id"),
            "time_start_utc": entry.get("time_start"),
            "time_end_utc": entry.get("time_end"),
            "granule_size_mb_as_reported_by_cmr": entry.get("granule_size"),
            "orbit_number": entry.get("orbit_number"),
            "day_night_flag": entry.get("day_night_flag"),
            "footprint_polygon_lat_lon_pairs": entry.get("polygons"),
            "cmr_bbox_intersection_query": BBOX,
            "data_access_links_metadata_only": data_links,
            "product_metadata_links": metadata_dois,
            "query_url": url,
            "response_headers": headers,
            "raw_metadata": f"raw/granule_{index:02d}_{producer_id}.json",
            "raw_metadata_sha256": digest,
            "cloud_phase": "unknown; no science QA or granule data was read",
        })
    result = OUT / "NASA_CMR_MODIS_cloud_granule_inventory_2026-10-07.json"
    result.write_text(json.dumps(receipt, indent=2, allow_nan=False) + "\n")
    print(json.dumps({"result": str(result),
                      "granules": [g["producer_granule_id"] for g in receipt["granules"]],
                      "hashes": [g["raw_metadata_sha256"] for g in receipt["granules"]]}, indent=2))


if __name__ == "__main__":
    main()
