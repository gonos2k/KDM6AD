"""Collect the actual PR378 checkout acceptance; no model is launched here."""
import hashlib,json,platform,subprocess,sys,zipfile
from pathlib import Path
import importlib.metadata as metadata
import xml.etree.ElementTree as ET
ROOT=Path('/private/tmp/KDM6AD-dry-number-optics')
RUN=Path('/private/tmp/KDM6AD-research-rc-20261007')
SOURCE=RUN/'source'
REV='30931e52f99e38f9abcd6e7e3b8cd055227a5c23'
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
def suite(name):
 r=ET.parse(RUN/(name+'.xml')).getroot();a=r.attrib if r.tag=='testsuite' else r.find('testsuite').attrib
 return {k:int(a.get(k,0)) for k in ('tests','failures','errors','skipped')}|{'time_seconds':float(a['time'])}
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip()==REV
assert not subprocess.check_output(['git','status','--porcelain'],cwd=SOURCE,text=True)
ctest,oracle=suite('ctest'),suite('oracle')
assert ctest['tests']==19 and ctest['failures']==0 and oracle['failures']==oracle['errors']==0
accept=json.loads((RUN/'acceptance-cases/acceptance.json').read_text())
assert accept['source_revision']==REV and accept['success_runs']==2 and accept['rejection_cases']==3
loaded=json.loads((RUN/'loaded-library-images.json').read_text())
for image in loaded['images']:assert sha(image['path'])==image['sha256']
assert sha(SOURCE/'libtorch/install/lib/libkdm6_c.2.0.0.dylib')==accept['library_sha256']
paths=['recipe-composition-check.txt','recipe-witness.py','dependencies.log','pip-check.log','configure.log','build.log','install.log','ctest.log','ctest.xml','oracle.log','oracle.xml','exports.log','loaded-library-images.json','accept_pr378.py','acceptance.log','collect_receipt.py','source/libtorch/build/CMakeCache.txt','source/libtorch/build/Testing/Temporary/LastTest.log']
paths += [str(p.relative_to(RUN)) for p in sorted((RUN/'acceptance-cases').rglob('*')) if p.is_file()]
source_files=subprocess.check_output(['git','ls-files','libtorch','oracle/kdm6','oracle/scripts','oracle/tests'],cwd=SOURCE,text=True).splitlines()
hashes={p:sha(SOURCE/p) for p in source_files}
for p,h in hashes.items():assert sha(ROOT/p)==h,p
cache=(SOURCE/'libtorch/build/CMakeCache.txt').read_text()
home=next(x.split('=',1)[1] for x in cache.splitlines() if x.startswith('CMAKE_HOME_DIRECTORY:'))
assert Path(home).resolve()==(SOURCE/'libtorch').resolve()
result=dict(artifact_role='current_user_recipe_revision_acceptance',source_revision=REV,source_clean_before_and_after=True,
 no_test_overlays=True,cmake_source_directory=home,source_file_hashes=hashes,library_sha256=accept['library_sha256'],
 guide_checkout_revision=REV,witness_retrieval='cloned tip before checkout; SHA checked',acceptance_witness_commit='6fcfffa5422f339ed353c9559f2e2c84147b6997',acceptance_witness_sha256=sha(RUN/'accept_pr378.py'),
 environment=dict(os=platform.platform(),python=sys.version,packages={n:metadata.version(n) for n in ('torch','numpy','netCDF4','pytest','pyproj')},cmake=subprocess.check_output(['cmake','--version'],text=True).splitlines()[0],cxx=subprocess.check_output(['clang++','--version'],text=True).splitlines()[0],fortran=subprocess.check_output(['gfortran','--version'],text=True).splitlines()[0]),
 ctest=ctest,public_only_oracle=oracle,abi_export_symbols=11,loaded_images=loaded,native_column=accept,
 raw_file_hashes={p:sha(RUN/p) for p in paths},
 scope=dict(historical_oct6_artifacts_unchanged=True,production_physics_and_abi_changed=False,native_host_or_kma_window_executed=False,independent_other_user_or_machine=False,published_release=False,physical_number_basis_resolved=False,accepted_observation_cost=False,operational_approval=False,licensing='UNRESOLVED'))
E=ROOT/'harness/evidence'
(E/'RESEARCH_CANDIDATE_revision_result_2026-10-07.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
with zipfile.ZipFile(E/'RESEARCH_CANDIDATE_revision_receipts_2026-10-07.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in paths:z.write(RUN/p,p)
print('Acceptance recorded',ctest,oracle,'source files',len(hashes),'raw files',len(paths))
