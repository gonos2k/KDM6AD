program p8w_helper
  implicit none
  integer, parameter :: n=39
  real :: p(n), pb(n), ph(n+1), phb(n+1), fnm(n), fnp(n)
  real :: pw(n+1), zw(n+1), z(n), z0,z1,z2,w1,w2
  integer :: k
  open(10,file='input.txt',status='old')
  do k=1,n; read(10,*) p(k); end do
  do k=1,n; read(10,*) pb(k); end do
  do k=1,n+1; read(10,*) ph(k); end do
  do k=1,n+1; read(10,*) phb(k); end do
  do k=1,n; read(10,*) fnm(k); end do
  do k=1,n; read(10,*) fnp(k); end do
  close(10)
  do k=1,n+1
     zw(k)=(phb(k)+ph(k))/9.81
  end do
  do k=1,n
     z(k)=0.5*(zw(k)+zw(k+1))
  end do
  do k=2,n
     pw(k)=fnm(k)*(p(k)+pb(k))+fnp(k)*(p(k-1)+pb(k-1))
  end do
  z0=zw(1); z1=z(1); z2=z(2)
  w1=(z0-z2)/(z1-z2); w2=1.-w1
  pw(1)=w1*(p(1)+pb(1))+w2*(p(2)+pb(2))
  z0=zw(n+1); z1=z(n); z2=z(n-1)
  w1=(z0-z2)/(z1-z2); w2=1.-w1
  pw(n+1)=exp(w1*log(p(n)+pb(n))+w2*log(p(n-1)+pb(n-1)))
  open(11,file='output.txt',status='replace')
  do k=1,n+1; write(11,'(ES25.17E3)') pw(k); end do
  close(11)
end program p8w_helper
