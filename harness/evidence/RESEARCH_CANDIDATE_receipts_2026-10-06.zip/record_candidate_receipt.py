"""Collect the executed candidate campaign; this collector launches no model."""
import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform
import re
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path('/private/tmp/KDM6AD-dry-number-optics')
RUN = Path('/private/tmp/KDM6AD-research-rc-20261006')
E = ROOT / 'harness/evidence'

def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''):h.update(b)
    return h.hexdigest()

def suite(name):
    r=ET.parse(RUN / f'{name}.xml').getroot()
    a=r.attrib if r.tag=='testsuite' else r.find('testsuite').attrib
    return {k:int(a.get(k,0)) for k in ('tests','failures','errors','skipped')} | {'time_seconds':float(a['time'])}

ctest=suite('ctest'); public=suite('oracle-public-final'); ambient=suite('oracle'); failed=suite('oracle-public-only')
assert ctest['tests']==19 and ctest['failures']==0 and public['failures']==public['errors']==0
assert failed['failures']==1 and ambient['failures']==0
accept=json.loads((RUN/'acceptance-cases/acceptance.json').read_text())
assert accept['success_runs']==2 and accept['array_content_raw_bit_equal'] and accept['rejection_cases']==3
loaded=json.loads((RUN/'loaded-library-images.json').read_text())
assert loaded['all_libtorch_images_from_fresh_environment']
for item in loaded['images']:assert sha(item['path'])==item['sha256']
assert sha(RUN/'install/lib/libkdm6_c.2.0.0.dylib')==accept['library_sha256']
raw=[('pip-check.log','pip-check.log'),('dependency-install.log','dependency-install.log'),('requirements-resolved.txt','requirements-resolved.txt'),
 ('configure.log','configure-mixed-discovery.log'),('configure-pinned.log','configure-pinned.log'),('build.log','build.log'),('install.log','install.log'),
 ('ctest.log','ctest.log'),('ctest.xml','ctest.xml'),('build/CMakeCache.txt','CMakeCache.txt'),('build/Testing/Temporary/LastTest.log','ctest-LastTest.log'),
 ('exports.log','exports.log'),('loaded-library-images.json','loaded-library-images.json'),
 ('oracle.log','oracle-with-local-rttov.log'),('oracle.xml','oracle-with-local-rttov.xml'),
 ('oracle-public-only.log','oracle-public-before-fix.log'),('oracle-public-only.xml','oracle-public-before-fix.xml'),
 ('oracle-public-final.log','oracle-public-final.log'),('oracle-public-final.xml','oracle-public-final.xml'),
 ('column-contract.log','column-contract.log'),('column-contract.xml','column-contract.xml'),
 ('updated-contracts-public.log','updated-contracts-public.log'),('updated-contracts-public.xml','updated-contracts-public.xml'),
 ('updated-asset-gate-present.log','updated-asset-gate-present.log'),('updated-asset-gate-present.xml','updated-asset-gate-present.xml'),
 ('record_candidate_receipt.py','record_candidate_receipt.py')]
raw += [(str(p.relative_to(RUN)),str(p.relative_to(RUN))) for p in sorted((RUN/'acceptance-cases').rglob('*')) if p.is_file()]
files={target:sha(RUN/src) for src,target in raw}
# Bind actual compiled production sources separately from the two test-only overlays.
compiled_files=subprocess.check_output(['git','ls-files','libtorch'],cwd=RUN/'source',text=True).splitlines()
compiled={p:sha(RUN/'source'/p) for p in compiled_files}
for p,h in compiled.items():assert sha(ROOT/p)==h,p
flags={str(p.relative_to(RUN)):p.read_text() for p in (RUN/'build/CMakeFiles').glob('*/flags.make')}
for name,text in flags.items():
    if 'CXX_FLAGS =' in text:
        assert '-ffp-contract=off' in text,name
        if '/test_' in name: assert '-UNDEBUG' in text,name
assert 'KDM6_ENABLE_TEST_HOOKS:BOOL=OFF' in (RUN/'build/CMakeCache.txt').read_text()
patches={str(p.relative_to(ROOT)):sha(p) for p in [ROOT/'oracle/tests/test_diagnose_clear_gradient_boundary.py', ROOT/'oracle/tests/test_normalized_dry_column_run.py']}
for p,h in patches.items():assert sha(RUN/'source'/p)==h,p
result=dict(artifact_role='source_only_research_candidate_acceptance',
 build_source_revision=accept['source_revision'], clean_clone_and_fresh_venv=True,
 compiled_source_hashes=compiled, actual_compile_flags=flags, final_test_only_overlay_hashes=patches,
 environment=dict(os=platform.platform(),python=sys.version,packages={n:importlib.metadata.version(n) for n in ('torch','numpy','netCDF4','pytest','pyproj','pip','setuptools')},
 cmake=subprocess.check_output(['cmake','--version'],text=True).splitlines()[0],cxx=subprocess.check_output(['clang++','--version'],text=True).splitlines()[0],fortran=subprocess.check_output(['gfortran','--version'],text=True).splitlines()[0]),
 build_policy=dict(type='Release',ffp_contract='off',test_assertions='-UNDEBUG',test_hooks=False,substep_dump=False,
 internal_fault_injection_sections='not executed in test-hooks-OFF installed candidate',
 default_cmake_discovery_selected_system_torch=True,explicit_library_pins_selected_fresh_env=True),
 ctest=ctest,abi_export_symbols=11,loaded_library_images=loaded,
 native_column=accept,success_output_hashes={str(p.relative_to(RUN)):sha(p) for p in sorted((RUN/'acceptance-cases').glob('success_*/*')) if p.is_file()},
 public_only_oracle=public,ambient_rttov_oracle=ambient,public_only_before_test_prerequisite_fix=failed,
 focused_filesystem_contract=suite('column-contract'),updated_contracts_public=suite('updated-contracts-public'),updated_profile_gate_assets_present=suite('updated-asset-gate-present'),
 test_counts_are_not_additive=True,warning_count_each_full_oracle=51,
 numerical_reference=dict(max_native_field_relative_fd_error=5.583113428056277e-8,duality_relative=1.7898345672809642e-16,unchanged_fd_threshold=1e-5,unchanged_duality_threshold=1e-12),
 prerequisite_fix='private clear-gradient test now also requires the reference T/Q/p_half files',
 assets=dict(native_forecast_provided_externally=True,input_sha256=accept['input_sha256'],
 ambient_rttov_home='/Users/yhlee/AD-RTTOV',public_only_rttov_paths=str(RUN/'empty-rttov'),
 private_source_binary_model_input_and_rttov_assets_not_distributed=True),
 scope=dict(native_host_forecast_executed=False,new_kma_window_executed=False,rt_fixture_tests_executed_only_in_ambient_run=True,
 independent_other_user_or_machine_acceptance=False,licensing='UNRESOLVED',published_release=False,
 physical_number_basis_resolved=False,accepted_observation_cost=False,operational_approval=False),
 raw_file_hashes=files,
 acceptance_source_sha256=sha(ROOT/'harness/evidence/RESEARCH_column_acceptance_source_2026-10-06.py'),
 resolved_dependency_file_sha256=sha(E/'RESEARCH_requirements_macos_arm64_2026-10-06.txt'))
(E/'RESEARCH_CANDIDATE_result_2026-10-06.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
archive=E/'RESEARCH_CANDIDATE_receipts_2026-10-06.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for src,target in raw:z.write(RUN/src,target)
print('Receipt written:',ctest,public,'raw files',len(raw),'ZIP',archive.stat().st_size)
