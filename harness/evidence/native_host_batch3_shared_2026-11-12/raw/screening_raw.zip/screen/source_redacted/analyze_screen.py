#!/usr/bin/env python3
"""Offline one-step finite-difference and AD comparison; no new model calls."""
import csv,gzip,hashlib,io,json,math,pathlib,struct
R=pathlib.Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest();f64=lambda w:struct.unpack('>d',bytes.fromhex(w))[0];w64=lambda x:struct.pack('>d',x).hex();FIELDS=('th','qv','qc','qr','qi','qs','qg','nccn','nc','ni','nr','bg','rho','pii','p','delz');N=39;H=1e-4
s=json.loads((R/'result.json').read_text());m=json.loads((R/'inputs.json').read_text());e=json.loads((R/'effective_result.json').read_text());assert s['status']=='complete' and e['parent_screen_sha256']==sha(R/'result.json') and s['inputs_sha256']==sha(R/'inputs.json');items={x['key']:x for x in m['inputs']};endpoints={x['key']:x for x in s['endpoints']};
def capture(key):
 raw=gzip.decompress((R/'calls'/(key+'_capture')/'capture.csv.gz').read_bytes()).decode(); rows=list(csv.DictReader(x for x in io.StringIO(raw) if not x.startswith('#'))); assert len(rows)==19656
 masks={};schedule={}
 for row in rows:
  k='|'.join(row[x] for x in ('one_step_call','runtime_call','substep','b_zero','k_zero','stage','field'))
  if row['dtype']=='bool':assert k not in masks;masks[k]=row['raw_hex']
  if row['stage'] in ('runtime_full_schedule','runtime_full_meta') and row['field'] in ('loops','mstep_ice_col','mstep_main_col','mstepmax_ice','mstepmax_main'):assert k not in schedule;schedule[k]=row['raw_hex']
 return masks,schedule

def output(key):return json.loads((R/'calls'/(key+'_capture')/'output.json').read_text())['output_words']
def field_summary(rows):
 result={}
 for field in FIELDS[:12]:
  a=[x for x in rows if x['field']==field];resolved=[x for x in a if x['signal']=='resolved_distinct_words' and x['finite']];scale=max((max(abs(x['fd']),abs(x['jvp'])) for x in resolved),default=0); result[field]={'resolved':len(resolved),'unresolved_equal_words':sum(x['signal']=='unresolved_equal_words' for x in a),'nonfinite':sum(not x['finite'] for x in a),'field_scale_max_abs_fd_or_jvp':scale,'max_abs_residual':max((abs(x['residual']) for x in resolved),default=None),'max_field_scaled_residual':max((abs(x['residual'])/scale for x in resolved),default=None) if scale else None,'max_relative_residual_resolved':max((abs(x['residual'])/max(abs(x['fd']),abs(x['jvp'])) for x in resolved if max(abs(x['fd']),abs(x['jvp']))>0),default=None)}
 return result
summaries=[]; details=[]
for center in ('baseline','lower','upper'):
 c=items['center_'+center]; cm,cs=capture('center_'+center); cw=output('center_'+center); eff=next(x for x in e['centers'] if x['center']==center); eg=json.loads((R/'effective_calls'/center/'output.json').read_text());ng=json.loads((R/'calls'/('center_'+center+'_graph')/'output.json').read_text());gs=list(map(f64,ng['vjp']['state_words']));gf=list(map(f64,ng['vjp']['forcing_words']))
 for direction in eff['effective_directions']:
  name=direction['id'];pluskey=f'{center}_{name}_+1';minuskey='center_'+center if name=='nc' else f'{center}_{name}_-1';plus=items[pluskey];minus=items[minuskey];pm,ps=capture(pluskey);mm,ms=(cm,cs) if name=='nc' else capture(minuskey); mask_changes={k:[cm.get(k),v.get(k)] for label,v in [('unused',{})] for k in []}; changed={side:[k for k in sorted(set(cm)|set(mm2)) if cm.get(k)!=mm2.get(k)] for side,mm2 in [('minus',mm),('plus',pm)]}; sched={side:[k for k in sorted(set(cs)|set(ss)) if cs.get(k)!=ss.get(k)] for side,ss in [('minus',ms),('plus',ps)]};assert (len(changed['plus']) if name!='nc' else len(changed['plus']))==endpoints[pluskey]['bool_changed_count'];
  if name!='nc':assert len(changed['minus'])==endpoints[minuskey]['bool_changed_count']
  a=output(minuskey);b=output(pluskey);jwords=eg['jvps'][name]['output_words'];assert len(a)==len(b)==len(jwords)==468;den=H if name=='nc' else 2*H;outrows=[]
  if name=='nc':
   secondkey=f'{center}_{name}_+2';sm,ss=capture(secondkey);changed['plus2']=[k for k in sorted(set(cm)|set(sm)) if cm.get(k)!=sm.get(k)];sched['plus2']=[k for k in sorted(set(cs)|set(ss)) if cs.get(k)!=ss.get(k)];second=output(secondkey)
  for i,(lo,hi,jw) in enumerate(zip(a,b,jwords)):
   lv=f64(lo);hv=f64(hi);j=f64(jw);fd=(hv-lv)/den;res=fd-j; finite=all(map(math.isfinite,(lv,hv,j,fd,res))); row={'field':FIELDS[i//39],'native_level_1based':i%39+1,'index':i,'lower_word':lo,'upper_word':hi,'jvp_word':jw,'fd_word':w64(fd),'fd':fd,'jvp':j,'residual':res,'finite':finite,'signal':'unresolved_equal_words' if lo==hi else 'resolved_distinct_words'}
   if name=='nc':row['second_forward_fd_word']=w64((4*(hv-lv)-(f64(second[i])-lv))/(2*H));row['plus2_word']=second[i]
   outrows.append(row)
  dot=0.0
  for field,scale in direction['seed'].items():
   idx=FIELDS.index(field[:-2]);dot+=(gs if idx<12 else gf)[(idx if idx<12 else idx-12)*N+15]*scale
  jnc=f64(jwords[8*N+15]); assert math.isfinite(dot) and math.isfinite(jnc)
  summary={'center':center,'direction':name,'stencil':'forward_first_order_and_second_forward_recorded' if name=='nc' else 'central','nominal_h':H,'nominal_seed':next(d['seed'] for d in c['directions'] if d['id']==name),'actual_represented_components':direction['represented_components'],'effective_seed':direction['seed'],'denominator':den,'captured_bool_changes':changed,'schedule_changes':sched,'captured_masks_and_schedule_stable':all(not v for v in changed.values()) and all(not v for v in sched.values()),'finite_count':sum(v['finite'] for v in outrows),'resolved_count':sum(v['signal']=='resolved_distinct_words' for v in outrows),'unresolved_equal_word_count':sum(v['signal']=='unresolved_equal_words' for v in outrows),'nc16_jvp':jnc,'nc16_vjp_dot_effective':dot,'jvp_minus_vjp_dot':jnc-dot,'nc16_fd':outrows[8*N+15]['fd'],'nc16_signal':outrows[8*N+15]['signal'],'fields':field_summary(outrows)};summaries.append(summary);details.append({'center':center,'direction':name,'outputs':outrows})
summary={'schema':'kdm6.batch3.screen.offline_comparison.v1','source_sha256':sha(__file__),'screen_sha256':sha(R/'result.json'),'inputs_sha256':sha(R/'inputs.json'),'effective_sha256':sha(R/'effective_result.json'),'h':H,'scope':'single nominal h; effective represented-component directions; finite distinct output words are resolution observations, not derivative accuracy or physical claims','scaling':'per field max absolute residual / max(abs(FD),abs(JVP)) across resolved outputs; individual max relative uses max(abs(FD),abs(JVP)); zero scale reports null','nc_stencil':'first-order forward for displayed FD; second-order forward word retained in detail','comparisons':summaries,'second_step_proposal':{'all_30_directions_at_second_h_endpoint_calls':120,'explanation':'3 centers × 10 directions × 2 endpoints × (installed value + capture-on); existing center graph reused with 3 additional effective-direction JVP graph calls if represented direction changes. NC uses +h/+2h. Reduced PII-only step: 3 centers × 2 endpoints × 2 builds = 12 value calls plus 3 effective-direction graph calls. h=1e-5 may still cross at lower/upper; inspect masks; h=1e-6 conditional. One additional h supports comparison, not automatic convergence certification.'}}
summary_path=R/'offline_summary.json';assert not summary_path.exists();summary_path.write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n');detail_path=R/'offline_detail.json.gz';assert not detail_path.exists();payload=(json.dumps({'schema':'kdm6.batch3.screen.offline_detail.v1','records':details},separators=(',',':'),allow_nan=False)+'\n').encode();
with detail_path.open('wb') as f:
 with gzip.GzipFile(filename='',fileobj=f,mode='wb',mtime=0) as gz:gz.write(payload)
print('summary',sha(summary_path),'detail',sha(detail_path));print('crossings',[(x['center'],x['direction']) for x in summaries if not x['captured_masks_and_schedule_stable']]);print('count',len(summaries))
