#!/usr/bin/env python3
"""Read-only audit of saved batch3 screen artifacts; makes no model calls."""
import csv,gzip,hashlib,io,json,math,pathlib,struct
R=pathlib.Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest();d64=lambda w:struct.unpack('>d',bytes.fromhex(w))[0];w64=lambda v:struct.pack('>d',v).hex();fields=('th','qv','qc','qr','qi','qs','qg','nccn','nc','ni','nr','bg','rho','pii','p','delz')
s=json.loads((R/'result.json').read_text());m=json.loads((R/'inputs.json').read_text());e=json.loads((R/'effective_result.json').read_text());assert s['status']=='complete' and s['calls']==126 and e['new_graph_calls']==3 and e['total_calls_including_parent']==129 and s['inputs_sha256']==sha(R/'inputs.json') and s['source_sha256']==sha(R/'screen.py') and e['parent_screen_sha256']==sha(R/'result.json') and e['source_sha256']==sha(R/'effective_jvp.py');by={v['key']:v for v in m['inputs']};assert len(by)==63
for item in m['inputs'][3:]:
 center=by['center_'+item['center']];a=center['state_words']+center['forcing_words'];b=item['state_words']+item['forcing_words'];actual={f'{fields[i//39]}16' for i,(x,y) in enumerate(zip(a,b)) if x!=y and i%39==15};assert actual==set(item['represented_deltas']) and all(x==y for i,(x,y) in enumerate(zip(a,b)) if i%39!=15)
 for k,v in item['represented_deltas'].items():
  i=fields.index(k[:-2])*39+15;assert (v['base_word'],v['input_word'],v['delta_word'])==(a[i],b[i],w64(d64(b[i])-d64(a[i])))
seen=set()
for rec in s['records']:
 key,mode=rec['key'],rec['mode']; assert (key,mode) not in seen;seen.add((key,mode));path=R/'calls'/(key+'_'+mode);assert sha(path/'input.json')==rec['input_sha256'] and sha(path/'output.json')==rec['output_sha256'] and sha(path/'loader.stderr.gz')==rec['stderr_gzip_sha256'];data=json.loads((path/'output.json').read_text());assert rec['process_returncode']==data['rc']==0 and not data['errors'] and data['handle_null_after'] and data['output_finite_count']==468
 if mode=='capture':
  raw=gzip.decompress((path/'capture.csv.gz').read_bytes());assert sha(path/'capture.csv.gz')==rec['capture_gzip_sha256'] and hashlib.sha256(raw).hexdigest()==rec['capture_csv_sha256'] and raw.rstrip().endswith(b'status=complete');rows=list(csv.DictReader(x for x in io.StringIO(raw.decode()) if not x.startswith('#')));assert len(rows)==19656
assert len(seen)==126
for center in ('baseline','lower','upper'):
 c=json.loads((R/'calls'/('center_'+center+'_capture')/'output.json').read_text());g=json.loads((R/'calls'/('center_'+center+'_graph')/'output.json').read_text());assert c['output_words']==g['output_words'] and len(g['jvps'])==10 and all(x['rc']==0 and x['finite_count']==468 for x in g['jvps'].values()) and g['vjp']['rc']==0 and g['vjp']['state_finite_count']==468 and g['vjp']['forcing_finite_count']==156
for item in s['endpoints']:
 key=item['key'];a=json.loads((R/'calls'/(key+'_installed')/'output.json').read_text());b=json.loads((R/'calls'/(key+'_capture')/'output.json').read_text());assert a['output_words']==b['output_words'] and item['installed_capture_exact_468'] and item['output_finite']
for x in e['centers']:
 folder=R/'effective_calls'/x['center'];assert sha(folder/'input.json')==x['input_sha256'] and sha(folder/'output.json')==x['output_sha256'] and sha(folder/'loader.stderr.gz')==x['loader_stderr_gzip_sha256'];output=json.loads((folder/'output.json').read_text());assert len(output['jvps'])==10 and all(v['rc']==0 and v['finite_count']==468 for v in output['jvps'].values())
 for d in x['effective_directions']:
  for component,v in d['represented_components'].items():assert v['delta_word']==w64(d64(v['upper_word'])-d64(v['lower_word'])) and v['effective_seed_word']==w64(d64(v['delta_word'])/v['denominator'])
changed={x['key']:x['bool_changed_keys'] for x in s['endpoints'] if x['bool_changed_count']};assert set(changed)=={'lower_pii_+1','upper_pii_-1'} and all(len(v)==4 for v in changed.values()) and all(not x['schedule_changed_keys'] for x in s['endpoints'])
print(json.dumps({'schema':'kdm6.batch3.screen.audit.v1','calls':129,'inputs':63,'endpoint_parity':60,'complete_capture_csvs':63,'nominal_jvps':30,'effective_jvps':30,'state_forcing_vjps':3,'mask_crossings':changed,'schedule_changes':0,'scope':'integrity and arithmetic checks only; no derivative accuracy or full process-branch claim'},indent=2))
