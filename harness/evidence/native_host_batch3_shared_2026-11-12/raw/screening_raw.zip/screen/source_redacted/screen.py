#!/usr/bin/env python3
"""Bounded selected-column screening; records values, not derivative certification."""
import csv,ctypes as C,gzip,hashlib,json,math,os,pathlib,struct,subprocess,sys,tempfile,time,traceback
R=pathlib.Path(__file__).resolve().parent;P=R.parent;SELECTED=P/'selected_full.json';PLAN=pathlib.Path('<REDACTED_PATH>');INST=pathlib.Path('<REDACTED_PATH>');CAP=pathlib.Path('<REDACTED_PATH>');TORCH=pathlib.Path('<REDACTED_PATH>');ARCH=P/'f64_da_boundary_20261112/result.json'
sha=lambda x:hashlib.sha256(pathlib.Path(x).read_bytes()).hexdigest();w64=lambda v:struct.pack('>d',v).hex();f64=lambda w:struct.unpack('>d',bytes.fromhex(w))[0];f32=lambda w:struct.unpack('>f',bytes.fromhex(w))[0];w32=lambda v:struct.pack('>f',v).hex();FIELDS=('th','qv','qc','qr','qi','qs','qg','nccn','nc','ni','nr','bg','rho','pii','p','delz'); D=C.c_double;H=C.c_void_p;PD=C.POINTER(D);PH=C.POINTER(H); arr=lambda x:(D*len(x))(*x)

def worker(mode,input_file,output_file):
 data=json.loads(pathlib.Path(input_file).read_text());x=list(map(f64,data['state_words']));f=list(map(f64,data['forcing_words']));lib=C.CDLL(str(INST if mode=='installed' else CAP));fun=lib.kdm6_step_ad_c if mode=='installed' else lib.kdm6_step_ad_state_forcing_c;types=[PD,PD,C.c_int,C.c_int,C.c_int,D,C.c_int,PD,PH,C.POINTER(C.c_float),D,D];fun.argtypes=types+([] if mode=='installed' else [C.c_uint32,C.c_int64]);fun.restype=C.c_int;close=lib.kdm6_handle_closep_c;close.argtypes=[PH];close.restype=C.c_int
 graph=mode=='graph';state=arr(x);forcing=arr(f);out=arr([float('nan')]*468);h=H();land=C.c_float(2);args=[state,forcing,1,39,1,20,0 if graph else 1,out,C.byref(h),C.byref(land),10,10];rc=fun(*args,*([] if mode=='installed' else [0,0]));had=bool(h.value);result={'schema':'kdm6.batch3.screen.call.v1','mode':mode,'input_key':data['key'],'rc':rc,'handle_nonnull':had,'output_words':list(map(w64,out)),'output_finite_count':sum(map(math.isfinite,out)),'jvps':{},'vjp':None}; errors=[]
 try:
  if rc!=0 or had!=graph:errors.append('forward rc/handle mismatch')
  if graph and rc==0 and had:
   j=lib.kdm6_handle_state_forcing_jvp_c;j.argtypes=[H,PD,PD,PD];j.restype=C.c_int;v=lib.kdm6_handle_state_forcing_vjp_c;v.argtypes=[H,PD,PD,PD];v.restype=C.c_int
   for d in data['directions']:
    vs=[0.]*468;vf=[0.]*156
    for name,scale in d['seed'].items():
     field=name[:-2];idx=FIELDS.index(field);(vs if idx<12 else vf)[(idx if idx<12 else idx-12)*39+15]=scale
    jv=arr([float('nan')]*468);jrc=j(h,arr(vs),arr(vf),jv);result['jvps'][d['id']]={'rc':jrc,'state_direction_words':list(map(w64,vs)),'forcing_direction_words':list(map(w64,vf)),'output_words':list(map(w64,jv)),'finite_count':sum(map(math.isfinite,jv))}
    if jrc:errors.append('jvp '+d['id'])
   u=[0.]*468;u[8*39+15]=1.;gs=arr([float('nan')]*468);gf=arr([float('nan')]*156);vrc=v(h,arr(u),gs,gf);result['vjp']={'rc':vrc,'seed':'nc16_unit','state_words':list(map(w64,gs)),'forcing_words':list(map(w64,gf)),'state_finite_count':sum(map(math.isfinite,gs)),'forcing_finite_count':sum(map(math.isfinite,gf))}
   if vrc:errors.append('vjp')
 finally:
  cr=close(C.byref(h)) if h.value else None;result['close_rc']=cr;result['handle_null_after']=not bool(h.value)
  if cr not in (None,0) or h.value:errors.append('close')
 result['errors']=errors;pathlib.Path(output_file).write_text(json.dumps(result,separators=(',',':'))+'\n')
 if errors:sys.exit(2)

if len(sys.argv)>1:
 worker(*sys.argv[1:]);sys.exit(0)
assert sha(SELECTED)=='e3117d277a073042bbae648b87e7dd6661d14b600fc8245f6aeabc19fe715eae' and sha(INST)=='7adcb6921f6205af66c62720ce9447928a1608f5c261546183b928bebbd9dba7' and sha(CAP)=='eabb607b08760a5b757031f864f6644e5f75aa83aebdc4c32f8fdfc8c2245c95' and sha(ARCH)=='c2a5260e2d1d3e33bf0bad718850394e72deeae7d1e7e4fa34ec84207a54b179'
plan=json.loads(PLAN.read_text());s=json.loads(SELECTED.read_text());words=[w for name in FIELDS for w in s['input_words_hex'][name]];base=list(map(f32,words));assert len(base)==624 and list(map(w32,base))==words and plan['h']==1e-4 and len(plan['directions'])==10 and len(plan['endpoints'])==60
centers={v['name']:v['word'] for v in plan['centers']}; directions={v['id']:v for v in plan['directions']};inputs=[]
def create_input(key,center,direction=None,multiple=0):
 val=base.copy();val[15]=f64(centers[center]);deltas={}
 if direction:
  for name,scale in directions[direction]['seed'].items():
   ix=FIELDS.index(name[:-2])*39+15;before=val[ix];val[ix]=before+multiple*plan['h']*scale;delta=val[ix]-before;assert delta!=0 and math.isfinite(val[ix]);deltas[name]={'base_word':w64(before),'input_word':w64(val[ix]),'delta_word':w64(delta),'delta':delta}
 assert all(math.isfinite(x) for x in val)
 for name in ('th','qv','nccn','rho','pii','p','delz'): assert val[FIELDS.index(name)*39+15]>0
 assert val[FIELDS.index('nc')*39+15]>=0
 return {'key':key,'center':center,'direction':direction,'h_multiple':multiple,'represented_deltas':deltas,'state_words':list(map(w64,val[:468])),'forcing_words':list(map(w64,val[468:])), 'directions':plan['directions'] if direction is None else []}
for c in centers:inputs.append(create_input('center_'+c,c))
for e in plan['endpoints']:inputs.append(create_input(e['key'].replace(':','_'),e['center'],e['direction'],e['h_multiple']))
assert len(inputs)==63 and len({tuple(x['state_words']+x['forcing_words']) for x in inputs})==63 and len({x['key'] for x in inputs})==63
manifest={'schema':'kdm6.batch3.screen.inputs.v1','selected_sha256':sha(SELECTED),'plan_sha256':sha(PLAN),'source_sha256':sha(__file__),'inputs':inputs,'numeric_admissibility':'finite all input words; target level TH/QV/NCCN/rho/pii/p/delz >0, NC >=0; not full physical moment-pair/unit validation'};(R/'inputs.json').write_text(json.dumps(manifest,indent=2)+'\n')
env={k:v for k,v in os.environ.items() if not k.startswith('KDM6') and not k.startswith('DYLD_')};env.update(OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OMP_THREAD_LIMIT='1',DYLD_LIBRARY_PATH=str(TORCH),DYLD_PRINT_LIBRARIES='1');deps={n:TORCH/n for n in ('libtorch.dylib','libtorch_cpu.dylib','libc10.dylib','libomp.dylib')};start=time.monotonic();results=[];limit_seconds=1200;call_limit=129; calls=0

def dump_progress(status,reason=None):
 data={'schema':'kdm6.batch3.screen.progress.v1','status':status,'reason':reason,'calls':calls,'records':results};tmp=R/'progress.json.tmp';tmp.write_text(json.dumps(data,indent=2)+'\n');os.replace(tmp,R/'progress.json')
def execute(data,mode):
 global calls
 if calls>=call_limit or time.monotonic()-start>limit_seconds:raise RuntimeError('call/time bound exceeded')
 tag=data['key']+'_'+mode;d=R/'calls'/tag;d.mkdir(parents=True,exist_ok=False);ip=d/'input.json';ip.write_text(json.dumps(data,separators=(',',':'))+'\n');op=d/'output.json';e=env.copy()
 if mode=='capture':e.update(KDM6_NATIVE_CAPTURE_DIR=str(d),KDM6_NATIVE_CAPTURE_ALL_K='1',KDM6_NATIVE_CAPTURE_CALL='1',KDM6_NATIVE_CAPTURE_B='0',KDM6_NATIVE_CAPTURE_MAX_ROWS='200000',KDM6_NATIVE_CAPTURE_MAX_BYTES='134217728')
 cmd=[sys.executable,str(R/'screen.py'),mode,str(ip),str(op)];calls+=1;beg=time.monotonic()
 try:proc=subprocess.run(cmd,env=e,capture_output=True,timeout=120)
 except subprocess.TimeoutExpired as ex:
  (d/'timeout.txt').write_text(str(ex));results.append({'key':data['key'],'mode':mode,'status':'timeout'});dump_progress('failed','call timeout');raise
 with gzip.open(d/'loader.stderr.gz','wb') as f:f.write(proc.stderr)
 (d/'stdout.bin').write_bytes(proc.stdout);entry={'key':data['key'],'mode':mode,'process_returncode':proc.returncode,'elapsed_seconds':time.monotonic()-beg,'input_sha256':sha(ip),'stderr_gzip_sha256':sha(d/'loader.stderr.gz')};results.append(entry)
 if proc.returncode or not op.exists():dump_progress('failed','worker failed');raise RuntimeError('worker failed '+tag)
 output=json.loads(op.read_text());entry['output_sha256']=sha(op);entry['rc']=output['rc'];entry['output_finite_count']=output['output_finite_count'];log=proc.stderr.decode(errors='replace');lib=INST if mode=='installed' else CAP
 if str(lib) not in log or any(str(dep) not in log for dep in deps.values()):raise RuntimeError('loader mismatch '+tag)
 if mode=='capture':
  fs=list(d.glob('native_qnice*.csv'));assert len(fs)==1;csvpath=fs[0];raw=csvpath.read_bytes();assert raw.rstrip().endswith(b'status=complete');entry['capture_csv_sha256']=hashlib.sha256(raw).hexdigest()
  with (d/'capture.csv.gz').open('wb') as stream:
   with gzip.GzipFile(filename='',fileobj=stream,mode='wb',mtime=0) as gz:gz.write(raw)
  entry['capture_gzip_sha256']=sha(d/'capture.csv.gz');csvpath.unlink()
 dump_progress('running');return output,entry

def classify(path):
 import io
 raw=gzip.decompress(path.read_bytes()).decode();rows=list(csv.DictReader(x for x in io.StringIO(raw) if not x.startswith('#')));m={};sched={}
 for row in rows:
  key='|'.join(row[k] for k in ('one_step_call','runtime_call','substep','b_zero','k_zero','stage','field'))
  if row['dtype']=='bool':
   if key in m:raise RuntimeError('duplicate bool capture')
   m[key]=row['raw_hex']
  if row['stage'] in ('runtime_full_schedule','runtime_full_meta') and row['field'] in ('loops','mstep_ice_col','mstep_main_col','mstepmax_ice','mstepmax_main'):
   if key in sched:raise RuntimeError('duplicate schedule capture')
   sched[key]=row['raw_hex']
 return m,sched,len(rows)

try:
 archive=json.loads(ARCH.read_text());old={e['th_word']:e['output_words'] for e in archive['events']};center_capture={};center_outputs={};
 for data in inputs[:3]:
  graph,_=execute(data,'graph');capture,entry=execute(data,'capture');assert graph['output_words']==capture['output_words']==old[centers[data['center']]],'center output parity';center_outputs[data['center']]=graph['output_words'];center_capture[data['center']]=classify(R/'calls'/(data['key']+'_capture')/'capture.csv.gz');entry['center_graph_installed_archive_parity']=True;print('center',data['center'],flush=True)
 endpoint_summary=[]
 for data in inputs[3:]:
  installed,_=execute(data,'installed');capture,entry=execute(data,'capture');same=installed['output_words']==capture['output_words'];entry['installed_capture_exact_468']=same
  masks,sched,nrows=classify(R/'calls'/(data['key']+'_capture')/'capture.csv.gz');cm,cs,_=center_capture[data['center']]; changed=[k for k in sorted(set(masks)|set(cm)) if masks.get(k)!=cm.get(k)];schanged=[k for k in sorted(set(sched)|set(cs)) if sched.get(k)!=cs.get(k)];activation=[k for k in changed if '|fd_satadj_inner|' in k];endpoint_summary.append({'key':data['key'],'installed_capture_exact_468':same,'output_finite':installed['output_finite_count']==capture['output_finite_count']==468,'capture_rows':nrows,'bool_mask_count':len(masks),'bool_changed_count':len(changed),'bool_changed_keys':changed,'activation_mask_changed_keys':activation,'schedule_changed_keys':schanged});
  if not same:raise RuntimeError('installed/capture output mismatch '+data['key'])
  print('endpoint',data['key'],'masks',len(changed),'schedule',len(schanged),flush=True)
  dump_progress('running')
 assert calls==126
 for pth,digest in ((SELECTED,manifest['selected_sha256']),(PLAN,manifest['plan_sha256']),(INST,'7adcb6921f6205af66c62720ce9447928a1608f5c261546183b928bebbd9dba7'),(CAP,'eabb607b08760a5b757031f864f6644e5f75aa83aebdc4c32f8fdfc8c2245c95')): assert sha(pth)==digest
 result={'schema':'kdm6.batch3.screen.v1','status':'complete','scope':'60 represented endpoints at one nominal h; captured-mask/schedule screening only; no derivative-accuracy, full branch or physical budget claim','inputs_sha256':sha(R/'inputs.json'),'source_sha256':sha(__file__),'installed_dso_sha256':sha(INST),'capture_dso_sha256':sha(CAP),'dependencies':{n:sha(p) for n,p in deps.items()},'python_sha256':sha(pathlib.Path(sys.executable).resolve()),'calls':calls,'call_limit':call_limit,'time_limit_seconds':limit_seconds,'elapsed_seconds':time.monotonic()-start,'center_bool_counts':{c:len(v[0]) for c,v in center_capture.items()},'center_schedule_counts':{c:len(v[1]) for c,v in center_capture.items()},'endpoints':endpoint_summary,'records':results};(R/'result.json').write_text(json.dumps(result,indent=2)+'\n');dump_progress('complete');print('DONE',sha(R/'result.json'),flush=True)
except BaseException as ex:
 dump_progress('failed',repr(ex));(R/'failure.txt').write_text(traceback.format_exc());print('FAILED',repr(ex),flush=True);raise
