#!/usr/bin/env python3
"""Bounded selected-column second-step screening; no physics or accuracy verdict."""
import csv,gzip,hashlib,io,json,math,os,pathlib,struct,subprocess,sys,time,traceback
R=pathlib.Path(__file__).resolve().parent;P=R.parent;OLD=P/'batch3_screening_20261112'; ARCH=P/'f64_da_boundary_20261112/interior_ad_fd.json'; INST=pathlib.Path('<REDACTED_PATH>'); CAP=pathlib.Path('<REDACTED_PATH>'); TORCH=pathlib.Path('<REDACTED_PATH>'); SELECTED=P/'selected_full.json'; WORKER=OLD/'screen.py'; sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest(); f64=lambda w:struct.unpack('>d',bytes.fromhex(w))[0]; w64=lambda x:struct.pack('>d',x).hex(); FIELDS=('th','qv','qc','qr','qi','qs','qg','nccn','nc','ni','nr','bg','rho','pii','p','delz'); H=1e-5;MAX_CALLS=126;MAX_SECONDS=900
assert sha(SELECTED)=='e3117d277a073042bbae648b87e7dd6661d14b600fc8245f6aeabc19fe715eae' and sha(INST)=='7adcb6921f6205af66c62720ce9447928a1608f5c261546183b928bebbd9dba7' and sha(CAP)=='eabb607b08760a5b757031f864f6644e5f75aa83aebdc4c32f8fdfc8c2245c95' and sha(WORKER)=='69130c49cc79330cb3ee54559acd32b59c16cf707167c392342a3948e184e17e' and sha(ARCH)=='0cc5a76fcef89bd9e540e55ef2acd7cfa60f837250115dce5762bb9d1f461ddc'
assert sha(OLD/'result.json')=='e90f9e53f61d2fc74f3aa3dec5764fbe2e3e0f3bd1b8ad2a96a5c89030d9d6eb' and sha(OLD/'offline_summary.json')=='d554580209306b5b9cc9bfc75ff439cd162012b4450257b28683e253b55eec8f'
old=json.loads((OLD/'result.json').read_text());inputs=json.loads((OLD/'inputs.json').read_text());summary=json.loads((OLD/'offline_summary.json').read_text());archive=json.loads(ARCH.read_text());by={x['key']:x for x in inputs['inputs']};directions={d['id']:d for d in by['center_baseline']['directions']}; selected={(x['center'],x['direction']) for x in summary['comparisons'] if x['resolved_count']>0};assert len(selected)==27 and all(d!='nccn' for _,d in selected)
centers={c:by['center_'+c] for c in ('baseline','lower','upper')};env={k:v for k,v in os.environ.items() if not k.startswith('KDM6') and not k.startswith('DYLD_')};env.update(OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OMP_THREAD_LIMIT='1',DYLD_LIBRARY_PATH=str(TORCH),DYLD_PRINT_LIBRARIES='1');deps={n:TORCH/n for n in ('libtorch.dylib','libtorch_cpu.dylib','libc10.dylib','libomp.dylib')};dep_hash={n:sha(p) for n,p in deps.items()};assert dep_hash==old['dependencies']

def make(c,d,h,mul):
 base=centers[c];state=base['state_words'].copy();forcing=base['forcing_words'].copy();delta={}
 for name,scale in directions[d]['seed'].items():
  ix=FIELDS.index(name[:-2]);arr=state if ix<12 else forcing;pos=(ix if ix<12 else ix-12)*39+15;before=f64(arr[pos]);after=before+mul*h*scale;arr[pos]=w64(after);diff=after-before;assert diff!=0 and math.isfinite(after);delta[name]={'base_word':w64(before),'word':arr[pos],'delta_word':w64(diff),'delta':diff}
 vals=list(map(f64,state+forcing));assert len(vals)==624 and all(map(math.isfinite,vals))
 for name in ('th','qv','nccn','rho','pii','p','delz'):assert vals[FIELDS.index(name)*39+15]>0
 assert vals[8*39+15]>=0
 return {'key':f'{c}_{d}_{h:.0e}_{mul:+d}','center':c,'direction':d,'nominal_h':h,'h_multiple':mul,'represented_deltas':delta,'state_words':state,'forcing_words':forcing,'directions':[]}

fixed=[]
for c,d in sorted(selected):
 for mult in ((1,2) if d=='nc' else (-1,1)):fixed.append(make(c,d,H,mult))
for c in centers:
 for mult in (1,2):fixed.append(make(c,'nc',1e-6,mult))
optional=[make(c,'pii',1e-6,m) for c in ('lower','upper') for m in (-1,1)]
assert len(fixed)==60 and len({tuple(v['state_words']+v['forcing_words']) for v in fixed})==60
manifest={'schema':'kdm6.batch3.adaptive.inputs.v1','selected_sha256':sha(SELECTED),'prior_screen_sha256':sha(OLD/'result.json'),'prior_summary_sha256':sha(OLD/'offline_summary.json'),'archive_sha256':sha(ARCH),'worker_sha256':sha(WORKER),'source_sha256':sha(__file__),'fixed_inputs':fixed,'optional_inputs':optional,'admissibility':'finite 624 inputs; target TH/QV/NCCN/rho/pii/p/delz >0, NC>=0; no full moment-pair, unit or hidden-branch claim'};(R/'inputs.json').write_text(json.dumps(manifest,indent=2)+'\n')
# Independently verify prior TH endpoint and full input words, not direction labels.
reuse={};archive_centers={x['name']:x for x in archive['centers']}
for data in fixed:
 if data['direction']=='th' and data['center'] in ('lower','upper'):
  c=archive_centers[data['center']];d=next(z for z in c['differences'] if z['h_requested']==H);side='lower' if data['h_multiple']==-1 else 'upper';assert d[side+'_word']==data['state_words'][15] and len(d[side]['output_words'])==468
  assert archive['parent_sha256']==sha(SELECTED) and archive['library_sha256']==sha(INST) and archive['controls']=={'shape':[1,39,1],'dt':20,'xland':2,'ncmin_land':10,'ncmin_sea':10,'threads':1,'physics_environment':'KDM6 variables unset'}
  reuse[data['key']]={'output_words':d[side]['output_words'],'archive_sha256':sha(ARCH),'center':data['center'],'side':side,'th_word':d[side+'_word']}
assert len(reuse)==4

def capture_signature(path):
 raw=gzip.decompress(path.read_bytes()).decode();rows=list(csv.DictReader(x for x in io.StringIO(raw) if not x.startswith('#')));mask={};schedule={}
 for row in rows:
  k='|'.join(row[x] for x in ('one_step_call','runtime_call','substep','b_zero','k_zero','stage','field'))
  if row['dtype']=='bool':assert k not in mask;mask[k]=row['raw_hex']
  if row['stage'] in ('runtime_full_schedule','runtime_full_meta') and row['field'] in ('loops','mstep_ice_col','mstep_main_col','mstepmax_ice','mstepmax_main'):assert k not in schedule;schedule[k]=row['raw_hex']
 return mask,schedule,len(rows)
center_sig={c:capture_signature(OLD/'calls'/('center_'+c+'_capture')/'capture.csv.gz') for c in centers};records=[];checks=[];calls=0;start=time.monotonic();status='running'
def progress(status,reason=None):
 tmp=R/'progress.tmp';tmp.write_text(json.dumps({'schema':'kdm6.batch3.adaptive.progress.v1','status':status,'reason':reason,'calls':calls,'records':records,'checks':checks},indent=2)+'\n');os.replace(tmp,R/'progress.json')
def execute(data,mode):
 global calls
 if calls>=MAX_CALLS or time.monotonic()-start>MAX_SECONDS:raise RuntimeError('global call/time bound')
 folder=R/'calls'/(data['key']+'_'+mode);folder.mkdir(parents=True,exist_ok=False);ip=folder/'input.json';ip.write_text(json.dumps(data,separators=(',',':'))+'\n');op=folder/'output.json';e=env.copy()
 if mode=='capture':e.update(KDM6_NATIVE_CAPTURE_DIR=str(folder),KDM6_NATIVE_CAPTURE_ALL_K='1',KDM6_NATIVE_CAPTURE_CALL='1',KDM6_NATIVE_CAPTURE_B='0',KDM6_NATIVE_CAPTURE_MAX_ROWS='200000',KDM6_NATIVE_CAPTURE_MAX_BYTES='134217728')
 cmd=[sys.executable,str(WORKER),mode,str(ip),str(op)];calls+=1;beg=time.monotonic()
 try: proc=subprocess.run(cmd,env=e,capture_output=True,timeout=min(120,max(1,MAX_SECONDS-(time.monotonic()-start))))
 except subprocess.TimeoutExpired as exc:records.append({'key':data['key'],'mode':mode,'status':'timeout','detail':str(exc)});progress('failed','timeout');raise
 with gzip.open(folder/'loader.stderr.gz','wb') as f:f.write(proc.stderr)
 (folder/'stdout.bin').write_bytes(proc.stdout);rec={'key':data['key'],'mode':mode,'process_returncode':proc.returncode,'elapsed_seconds':time.monotonic()-beg,'input_sha256':sha(ip),'stderr_gzip_sha256':sha(folder/'loader.stderr.gz')};records.append(rec)
 if proc.returncode or not op.exists():progress('failed','worker failed');raise RuntimeError('worker failure '+data['key']+' '+mode)
 out=json.loads(op.read_text());rec.update(output_sha256=sha(op),rc=out['rc'],output_finite_count=out['output_finite_count']); log=proc.stderr.decode(errors='replace');lib=INST if mode=='installed' else CAP
 if str(lib) not in log or any(str(p) not in log or sha(p)!=dep_hash[n] for n,p in deps.items()):raise RuntimeError('loader/dependency mismatch')
 if mode=='capture':
  files=list(folder.glob('native_qnice*.csv'));assert len(files)==1;fp=files[0];raw=fp.read_bytes();assert raw.rstrip().endswith(b'status=complete');rec['capture_csv_sha256']=hashlib.sha256(raw).hexdigest()
  with (folder/'capture.csv.gz').open('wb') as f:
   with gzip.GzipFile(filename='',fileobj=f,mode='wb',mtime=0) as gz:gz.write(raw)
  rec['capture_gzip_sha256']=sha(folder/'capture.csv.gz');fp.unlink()
 progress('running');return out

def run_pair(data):
 if data['key'] in reuse:
  installed={'output_words':reuse[data['key']]['output_words'],'output_finite_count':468}; records.append({'key':data['key'],'mode':'installed_reuse','proof':reuse[data['key']]})
 else:installed=execute(data,'installed')
 cap=execute(data,'capture');eq=installed['output_words']==cap['output_words']; masks,schedule,nrows=capture_signature(R/'calls'/(data['key']+'_capture')/'capture.csv.gz');cm,cs,_=center_sig[data['center']];changed=[k for k in sorted(set(cm)|set(masks)) if cm.get(k)!=masks.get(k)];schanged=[k for k in sorted(set(cs)|set(schedule)) if cs.get(k)!=schedule.get(k)];checks.append({'key':data['key'],'installed_capture_468_equal':eq,'output_finite':installed['output_finite_count']==cap['output_finite_count']==468,'bool_changed_keys':changed,'activation_mask_changed_keys':[k for k in changed if '|fd_satadj_inner|' in k],'schedule_changed_keys':schanged,'capture_rows':nrows});progress('running')
 if not eq:raise RuntimeError('installed/capture mismatch '+data['key'])
 print('endpoint',data['key'],'mask_changes',len(changed),'schedule',len(schanged),flush=True)

def seed_for(c,d,h):
 plus=make(c,d,h,1);minus=centers[c] if d=='nc' else make(c,d,h,-1);den=h if d=='nc' else 2*h;seed={};components={}
 for field in directions[d]['seed']:
  idx=FIELDS.index(field[:-2]);arr='state_words' if idx<12 else 'forcing_words';pos=(idx if idx<12 else idx-12)*39+15;lo=f64(minus[arr][pos]);hi=f64(plus[arr][pos]);value=(hi-lo)/den;seed[field]=value;components[field]={'lower_word':w64(lo),'upper_word':w64(hi),'effective_seed_word':w64(value),'denominator':den}
 return {'id':d+'_'+f'{h:.0e}','domain':directions[d]['domain'],'seed':seed,'stencil':directions[d]['stencil'],'represented_components':components}
try:
 for data in fixed:run_pair(data)
 graphs={}
 for c in centers:
  data=dict(centers[c]);data['key']='adaptive_center_'+c; data['directions']=[seed_for(c,d,H) for cc,d in sorted(selected) if cc==c]+[seed_for(c,'nc',1e-6)]+([seed_for(c,'pii',1e-6)] if c in ('lower','upper') else []);g=execute(data,'graph');oldgraph=json.loads((OLD/'calls'/('center_'+c+'_graph')/'output.json').read_text());assert g['output_words']==oldgraph['output_words'] and g['vjp']['state_words']==oldgraph['vjp']['state_words'] and g['vjp']['forcing_words']==oldgraph['vjp']['forcing_words'];graphs[c]=g
  print('graph',c,flush=True)
 decisions=[]
 for c in ('lower','upper'):
  keys=[f'{c}_pii_1e-05_{x:+d}' for x in (-1,1)];found=[next(x for x in checks if x['key']==k) for k in keys];stable=all(not x['bool_changed_keys'] and not x['schedule_changed_keys'] for x in found);lo=json.loads((R/'calls'/(keys[0]+'_capture')/'output.json').read_text())['output_words'][8*39+15];hi=json.loads((R/'calls'/(keys[1]+'_capture')/'output.json').read_text())['output_words'][8*39+15];fd=(f64(hi)-f64(lo))/(2*H);jvp=f64(graphs[c]['jvps']['pii_1e-05']['output_words'][8*39+15]);rel=abs(fd-jvp)/max(abs(fd),abs(jvp)) if max(abs(fd),abs(jvp)) else 0;unresolved=lo==hi;high=rel>0.01;take=stable and (unresolved or high);decision={'center':c,'stable_captured_masks_and_schedule':stable,'nc16_unresolved_equal_words':unresolved,'nc16_fd':fd,'nc16_jvp':jvp,'relative_residual':rel,'high_residual_threshold':0.01,'qualifies_for_h1e6':take,'executed':False}
  if take:
   needed=4
   if calls+needed>MAX_CALLS or time.monotonic()-start>=MAX_SECONDS:decision['deferred']='hard bound'
   else:
    for x in optional:
     if x['center']==c:run_pair(x)
    decision['executed']=True
  decisions.append(decision)
 assert calls<=MAX_CALLS and time.monotonic()-start<=MAX_SECONDS
 for pth,digest in [(SELECTED,manifest['selected_sha256']),(INST,'7adcb6921f6205af66c62720ce9447928a1608f5c261546183b928bebbd9dba7'),(CAP,'eabb607b08760a5b757031f864f6644e5f75aa83aebdc4c32f8fdfc8c2245c95'),(ARCH,manifest['archive_sha256']),(WORKER,manifest['worker_sha256'])]:assert sha(pth)==digest
 result={'schema':'kdm6.batch3.adaptive.screen.v1','status':'complete','calls':calls,'call_limit':MAX_CALLS,'elapsed_seconds':time.monotonic()-start,'time_limit_seconds':MAX_SECONDS,'source_sha256':sha(__file__),'inputs_sha256':sha(R/'inputs.json'),'installed_dso_sha256':sha(INST),'capture_dso_sha256':sha(CAP),'dependencies':dep_hash,'python_sha256':sha(pathlib.Path(sys.executable).resolve()),'reuse_count':len(reuse),'checks':checks,'conditional_pii':decisions,'records':records,'scope':'single h1e-5 with NC h1e-6 and conditional PII h1e-6, f64 selected column; no automatic accuracy, hidden-branch or unit/physical claim'};(R/'result.json').write_text(json.dumps(result,indent=2)+'\n');progress('complete');print('DONE',sha(R/'result.json'),flush=True)
except BaseException as ex:
 progress('failed',repr(ex));(R/'failure.txt').write_text(traceback.format_exc());print('FAILED',repr(ex),flush=True);raise
