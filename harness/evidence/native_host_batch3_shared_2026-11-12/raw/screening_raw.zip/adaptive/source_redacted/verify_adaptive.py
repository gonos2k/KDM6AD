#!/usr/bin/env python3
"""Offline integrity audit; no model calls."""
import csv,gzip,hashlib,io,json,pathlib,struct
R=pathlib.Path(__file__).resolve().parent;OLD=R.parent/'batch3_screening_20261112';sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest();f=lambda w:struct.unpack('>d',bytes.fromhex(w))[0];word=lambda x:struct.pack('>d',x).hex();r=json.loads((R/'result.json').read_text());m=json.loads((R/'inputs.json').read_text());a=json.loads((R/'analysis.json').read_text());assert r['status']=='complete' and r['calls']==123 and r['calls']<=r['call_limit']==126 and r['elapsed_seconds']<r['time_limit_seconds']==900 and r['inputs_sha256']==sha(R/'inputs.json') and r['source_sha256']==sha(R/'adaptive.py') and a['source_sha256']==sha(R/'analyze_adaptive.py') and a['adaptive_result_sha256']==sha(R/'result.json')
inputs={x['key']:x for x in m['fixed_inputs']+m['optional_inputs']};fields=('th','qv','qc','qr','qi','qs','qg','nccn','nc','ni','nr','bg','rho','pii','p','delz');old=json.loads((OLD/'inputs.json').read_text());centers={x['center']:x for x in old['inputs'] if x['direction'] is None}
for x in inputs.values():
 c=centers[x['center']];before=c['state_words']+c['forcing_words'];after=x['state_words']+x['forcing_words'];actual={f'{fields[i//39]}16' for i,(a,b) in enumerate(zip(before,after)) if a!=b and i%39==15};assert actual==set(x['represented_deltas']) and all(a==b for i,(a,b) in enumerate(zip(before,after)) if i%39!=15)
 for name,v in x['represented_deltas'].items():
  idx=fields.index(name[:-2])*39+15; assert (v['base_word'],v['word'],v['delta_word'])==(before[idx],after[idx],word(f(after[idx])-f(before[idx])))
seen=set();reuse={}
for rec in r['records']:
 key,mode=rec['key'],rec['mode'];assert (key,mode) not in seen;seen.add((key,mode))
 if mode=='installed_reuse':reuse[key]=rec['proof'];continue
 p=R/'calls'/(key+'_'+mode);assert rec['process_returncode']==rec['rc']==0 and sha(p/'input.json')==rec['input_sha256'] and sha(p/'output.json')==rec['output_sha256'] and sha(p/'loader.stderr.gz')==rec['stderr_gzip_sha256'];d=json.loads((p/'output.json').read_text());assert d['rc']==0 and d['handle_null_after'] and not d['errors'] and d['output_finite_count']==468
 if mode=='graph':assert len(d['jvps']) in (10,11) and all(v['rc']==0 and v['finite_count']==468 for v in d['jvps'].values()) and d['vjp']['rc']==0 and d['vjp']['state_finite_count']==468 and d['vjp']['forcing_finite_count']==156
 if mode=='capture':
  raw=gzip.decompress((p/'capture.csv.gz').read_bytes());assert sha(p/'capture.csv.gz')==rec['capture_gzip_sha256'] and hashlib.sha256(raw).hexdigest()==rec['capture_csv_sha256'] and raw.rstrip().endswith(b'status=complete');assert len(list(csv.DictReader(x for x in io.StringIO(raw.decode()) if not x.startswith('#'))))==19656
assert len(seen)==127 and len(reuse)==4
for x in r['checks']:
 key=x['key']; cap=json.loads((R/'calls'/(key+'_capture')/'output.json').read_text())['output_words'];inst=reuse[key]['output_words'] if key in reuse else json.loads((R/'calls'/(key+'_installed')/'output.json').read_text())['output_words'];assert cap==inst and x['installed_capture_468_equal'] and x['output_finite'] and not x['bool_changed_keys'] and not x['schedule_changed_keys']
assert len(r['checks'])==62 and len(a['records'])==31
print(json.dumps({'schema':'kdm6.batch3.adaptive.audit.v1','calls':123,'reused_installed_calls':4,'complete_captures':62,'endpoint_468_word_parity':62,'graph_handles':3,'analyzed_pairs':31,'all_recorded_masks_and_schedule_stable':True,'scope':'artifact/hash/numeric preflight audit only; no hidden-branch or derivative accuracy claim'},indent=2))
